const http = require('http');
const app = require('./app'); // Import de la configuration Express
const mongoose = require('mongoose');

// Connexion MongoDB
const localDbUrl = 'mongodb://localhost:27017/ecommerceDB';
mongoose.connect(localDbUrl)
    .then(() => {
        console.log('Connexion à MongoDB réussie !');

        // Démarrage du serveur si la DB est connectée
        const server = http.createServer(app);
        const port = 3000;

        server.listen(port, () => {
            console.log(`Serveur démarré et écoutant sur le port ${port}`);
        });

    })
    .catch((error) => {
        console.log('Connexion à MongoDB échouée !');
        console.error(error);
    });