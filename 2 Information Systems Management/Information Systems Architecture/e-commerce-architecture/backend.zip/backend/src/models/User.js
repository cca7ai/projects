const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    // Champs d'authentification
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true, // Assure l'uniformité des emails
        trim: true
    },
    password: {
        type: String,
        required: true
    },

    // Champs spécifiques au profil
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        required: true
    },
    phoneNumber: {
        type: String,
        required: false
    },

    // Champ essentiel pour la gestion des accès (rôles)
    role: {
        type: String,
        required: true,
        enum: ['client', 'sav', 'admin'],
        default: 'client'
    },

    // Métadonnées
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('User', userSchema);