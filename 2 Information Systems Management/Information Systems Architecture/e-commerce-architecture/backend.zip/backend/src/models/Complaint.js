const mongoose = require('mongoose');

// Enum pour standardiser les statuts de la réclamation
const ComplaintStatus = {
    NEW: 'Nouveau',
    IN_PROGRESS: 'En cours',
    RESOLVED: 'Résolu',
    CLOSED: 'Fermé'
};

const complaintSchema = new mongoose.Schema({
    // Lien vers l'utilisateur (client) qui a créé la réclamation
    userId: {
        type: mongoose.Schema.Types.ObjectId, // Référence à l'ID de l'utilisateur
        ref: 'User', // Fait référence au modèle 'User'
        required: true
    },

    // Informations sur la réclamation
    subject: {
        type: String,
        required: true,
        maxlength: 100
    },
    description: {
        type: String,
        required: true
    },

    // Suivi et gestion par le SAV
    status: {
        type: String,
        required: true,
        enum: Object.values(ComplaintStatus), // Utilise l'énumération définie
        default: ComplaintStatus.NEW
    },
    assignedTo: {
        type: mongoose.Schema.Types.ObjectId, // Référence à un utilisateur SAV/Admin
        ref: 'User',
        required: false, // Non obligatoire au début
        default: null
    },

    // Dates
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

// Mise à jour automatique de la date de modification
complaintSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

module.exports = mongoose.model('Complaint', complaintSchema);