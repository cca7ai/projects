const mongoose = require('mongoose');

const complaintCommentSchema = mongoose.Schema({
    // 1. Lien vers la Plainte
    complaintId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Complaint', // Référence au modèle Complaint
        required: true,
    },

    // 2. Lien vers l'Auteur
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', // Référence au modèle User (celui qui a écrit le commentaire)
        required: true,
    },

    // 3. Contenu du commentaire
    content: {
        type: String,
        required: true,
        trim: true,
    },

    // 4. Type de commentaire (pour le filtrage)
    commentType: {
        type: String,
        enum: ['client_comment', 'sav_note', 'status_change'], // Exemples de types
        default: 'client_comment',
    },
}, {
    // Ajoute automatiquement les champs createdAt et updatedAt
    timestamps: true
});

module.exports = mongoose.model('ComplaintComment', complaintCommentSchema);