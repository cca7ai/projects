const express = require('express');
const bodyParser = require('body-parser'); // Souvent nécessaire pour Express
const cors = require('cors'); // Pour permettre la communication Angular <> Express
const authRoutes = require('./routes/auth.routes');
const complaintRoutes = require('./routes/complaint.routes');
const userRoutes = require('./routes/user.routes');
const commentRoutes = require('./routes/comment.routes');

const app = express();

// Middleware pour la gestion de CORS
app.use(cors({
    origin: 'http://localhost:4200' // Adresse frontend Angular
    // Ou 'http://localhost:4200' si on n'utilise pas de proxy
}));

// Middleware pour analyser les requêtes JSON (body-parser est inclus dans express)
app.use(express.json());

// Routes d'authentification
app.use('/api/auth', authRoutes); // Toutes les routes auth.routes.js sont préfixées par /api/auth

// Routes de Réclamation
app.use('/api/complaints', complaintRoutes);

// Routes Utilisateur
app.use('/api/users', userRoutes);

// Routes de Commentaires/Historique
app.use('/api/comments', commentRoutes);

module.exports = app;