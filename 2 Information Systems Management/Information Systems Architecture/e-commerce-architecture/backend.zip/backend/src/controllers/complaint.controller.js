const Complaint = require('../models/Complaint');
const mongoose = require('mongoose');
const notificationService = require('../services/notification.service');

// ----------------------
// Créer une nouvelle réclamation
// ----------------------
exports.createComplaint = async (req, res) => {
    try {
        // L'ID utilisateur et le RÔLE sont attachés à req.auth par le middleware !
        const { userId, role } = req.auth;

        // Uniquement les clients peuvent créer des réclamations
        if (role !== 'client') {
            return res.status(403).json({ error: 'Seuls les clients peuvent soumettre une réclamation.' });
        }

        // 1. Créer la nouvelle réclamation
        const newComplaint = new Complaint({
            ...req.body, // Récupère le subject et la description envoyés par le client
            userId: userId, // ATTRIBUE automatiquement l'ID du client authentifié
            status: 'Nouveau' // Statut initial
        });
        newComplaint._id = undefined;

        // 2. Sauvegarder dans la base de données
        await newComplaint.save();

        // 3. Réponse réussie
        res.status(201).json({
            message: 'Réclamation soumise avec succès !',
            complaintId: newComplaint._id
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Échec de la soumission de la réclamation.' });
    }
};

// ----------------------
// Rêcuperer la liste des réclamations
// Clients voient leurs réclamations; SAV/Admin voient tout.
// ----------------------
exports.getComplaints = async (req, res) => {
    try {
        const { userId, role } = req.auth;
        let query = {}; // Requête par défaut pour tout le monde

        // Si l'utilisateur est un client, il ne voit que ses propres plaintes.
        if (role === 'client') {
            query.userId = userId;
        }

        // On utilise .populate('userId') pour remplacer l'ID par les infos utilisateur complètes
        // et on trie par la plus récente.
        const complaints = await Complaint.find(query)
            .populate('userId', 'firstName lastName email') // Popule avec le nom et l'email du créateur
            .populate('assignedTo', 'firstName lastName email') // Popule avec le nom de l'agent assigné
            .sort({ createdAt: -1 }); // Triage du plus récent au plus ancien

        res.status(200).json(complaints);

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Échec de la récupération des réclamations.' });
    }
};

// ----------------------
// Rêcuperer une réclamation par ID
// ----------------------
exports.getOneComplaint = async (req, res) => {
    try {
        const { userId, role } = req.auth;
        const complaintId = req.params.id;

        const complaint = await Complaint.findById(complaintId)
            .populate('userId', 'firstName lastName email')
            .populate('assignedTo', 'firstName lastName email');

        if (!complaint) {
            return res.status(404).json({ error: 'Réclamation non trouvée.' });
        }

        // Vérification d'accès : Seul le client qui a créé la plainte, le SAV ou l'Admin peut y accéder.
        if (role === 'client' && complaint.userId._id.toString() !== userId) {
            return res.status(403).json({ error: 'Accès refusé. Cette réclamation ne vous appartient pas.' });
        }

        res.status(200).json(complaint);

    } catch (error) {
        if (error instanceof mongoose.Error.CastError) {
            return res.status(400).json({ error: 'ID de réclamation invalide.' });
        }
        res.status(500).json({ error: 'Échec de la récupération de la réclamation.' });
    }
};

// ----------------------
// Mettre à jour une réclamation (SAV / Admin seulement)
// ----------------------
exports.updateComplaint = async (req, res) => {
    try {
        const { role } = req.auth;
        const complaintId = req.params.id;
        const updateData = req.body;

        // 1. Contrôle de rôle : Seuls le SAV ou l'Admin peuvent mettre à jour.
        if (role !== 'sav' && role !== 'admin') {
            return res.status(403).json({ error: 'Accès refusé. Seuls le SAV et l\'Admin peuvent modifier une réclamation.' });
        }

        // 2. Prévention des mises à jour non autorisées par le client (par sécurité)
        if (updateData.userId || updateData.createdAt) {
            delete updateData.userId;
            delete updateData.createdAt;
        }

        // 3. Exécution de la mise à jour
        const updatedComplaint = await Complaint.findByIdAndUpdate(
            complaintId,
            { $set: updateData },
            { new: true, runValidators: true } // new: true retourne le document mis à jour
        ).populate('userId', 'email');

        if (!updatedComplaint) {
            return res.status(404).json({ error: 'Réclamation non trouvée pour la mise à jour.' });
        }

        // 4. Notification asynchrone (SI le statut a changé ou est présent)
        if (updatedComplaint.status) {
            await notificationService.sendComplaintStatusUpdate(
                updatedComplaint.userId.email,
                updatedComplaint._id.toString(),
                updatedComplaint.status
            );
        }
        res.status(200).json({
            message: 'Réclamation mise à jour avec succès.',
            complaint: updatedComplaint
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Échec de la mise à jour de la réclamation.' });
    }
};

