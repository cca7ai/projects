const ComplaintComment = require('../models/ComplaintComment');
const Complaint = require('../models/Complaint');

// ----------------------
// Créer un nouveau commentaire pour une plainte
// ----------------------
exports.createComment = async (req, res) => {
    try {
        const { userId, role } = req.auth;
        const complaintId = req.params.complaintId;
        const { content } = req.body;

        // 1. Vérifier si la plainte existe
        const complaint = await Complaint.findById(complaintId);
        if (!complaint) {
            return res.status(404).json({ error: 'Plainte non trouvée.' });
        }

        // 2. Déterminer le type de commentaire et l'autorisation
        let commentType = 'client_comment';

        if (role === 'sav' || role === 'admin') {
            commentType = 'sav_note';
        }

        // Un client ne peut commenter que SA propre plainte
        if (role === 'client' && complaint.userId.toString() !== userId) {
            return res.status(403).json({ error: 'Accès refusé. Vous ne pouvez commenter que vos propres plaintes.' });
        }

        // 3. Création du commentaire
        const comment = new ComplaintComment({
            complaintId: complaintId,
            userId: userId,
            content: content,
            commentType: commentType,
        });

        await comment.save();

        res.status(201).json({ message: 'Commentaire ajouté avec succès.', comment });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erreur lors de l\'ajout du commentaire.' });
    }
};

// ----------------------
// Récupérer tous les commentaires pour une plainte (l'historique)
// ----------------------
exports.getCommentsByComplaint = async (req, res) => {
    try {
        const { userId, role } = req.auth;
        const complaintId = req.params.complaintId;

        // 1. Vérifier si la plainte existe
        const complaint = await Complaint.findById(complaintId);
        if (!complaint) {
            return res.status(404).json({ error: 'Plainte non trouvée.' });
        }

        // 2. Contrôle d'autorisation
        // Un client peut voir l'historique seulement si c'est sa plainte.
        if (role === 'client' && complaint.userId.toString() !== userId) {
            return res.status(403).json({ error: 'Accès refusé. Historique privé.' });
        }

        // 3. Récupération des commentaires, triés par date de création (les plus anciens en premier)
        const comments = await ComplaintComment.find({ complaintId: complaintId })
            .populate('userId', 'firstName lastName role') // Popule l'auteur du commentaire
            .sort({ createdAt: 1 }); // Ordre chronologique

        res.status(200).json(comments);

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erreur lors de la récupération de l\'historique.' });
    }
};