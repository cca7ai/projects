const User = require('../models/User'); // Import du modèle utilisateur
const bcrypt = require('bcrypt'); // Pour le hachage des mots de passe
const jwt = require('jsonwebtoken'); // Pour la génération du token

// ----------------------
// Gérer l'inscription de nouveaux utilisateurs (signup)
// ----------------------
exports.signup = async (req, res) => {
    try {
        // 1. Hacher le mot de passe
        const hashedPassword = await bcrypt.hash(req.body.password, 10); // 10 est le 'saltRounds'

        // 2. Créer une nouvelle instance d'utilisateur
        const user = new User({
            email: req.body.email,
            password: hashedPassword,
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            role: req.body.role || 'client' // Par défaut 'client' si non spécifié
        });

        // 3. Sauvegarder l'utilisateur dans la base de données
        await user.save();

        // 4. Réponse réussie
        res.status(201).json({
            message: 'Utilisateur créé !',
            userId: user._id
        });

    } catch (error) {
        // Gérer les erreurs, notamment l'email déjà utilisé (code 11000)
        if (error.code === 11000) {
            return res.status(400).json({ error: 'Cet email est déjà enregistré.' });
        }
        res.status(500).json({ error: 'Erreur serveur lors de l\'inscription.' });
    }
};

// ----------------------
// Gérer la connexion des utilisateurs (login)
// ----------------------
exports.login = async (req, res) => {
    try {
        // 1. Trouver l'utilisateur par email
        const user = await User.findOne({ email: req.body.email });
        if (!user) {
            return res.status(401).json({ error: 'Identifiants invalides (utilisateur non trouvé).' });
        }

        // 2. Comparer le mot de passe fourni avec le hachage dans la DB
        const isValid = await bcrypt.compare(req.body.password, user.password);
        if (!isValid) {
            return res.status(401).json({ error: 'Identifiants invalides (mot de passe incorrect).' });
        }

        // 3. Générer le JSON Web Token (JWT)
        const token = jwt.sign(
            { userId: user._id, role: user.role }, // Payload (les données stockées dans le token)
            'RANDOM_TOKEN_SECRET_CHANGE_ME_IN_PROD', // Clé secrète (À changer !)
            { expiresIn: '24h' } // Expiration du token
        );

        // 4. Réponse réussie avec le token et l'ID utilisateur
        res.status(200).json({
            userId: user._id,
            role: user.role,
            token: token
        });

    } catch (error) {
        res.status(500).json({ error: 'Erreur serveur lors de la connexion.' });
    }
};