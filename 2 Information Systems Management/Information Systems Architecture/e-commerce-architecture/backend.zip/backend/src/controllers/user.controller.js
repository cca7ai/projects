const User = require('../models/User');
const bcrypt = require('bcrypt'); // Pour le hachage lors de la mise à jour du mot de passe

// ----------------------
// Rêcuperer un utilisateur par son ID (Profil)
// ----------------------
exports.getOneUser = async (req, res) => {
    try {
        const userIdToFind = req.params.id;
        const requestingUser = req.auth; // Utilisateur faisant la requête (attaché par le middleware)

        // Autoriser l'accès uniquement si l'utilisateur demande son propre profil OU s'il est Admin/SAV
        if (userIdToFind !== requestingUser.userId.toString() && requestingUser.role === 'client') {
            return res.status(403).json({ error: 'Accès refusé. Non autorisé à voir ce profil.' });
        }

        const user = await User.findById(userIdToFind).select('-password'); // Exclure le mot de passe

        if (!user) {
            return res.status(404).json({ error: 'Utilisateur non trouvé.' });
        }

        res.status(200).json(user);

    } catch (error) {
        res.status(500).json({ error: 'Erreur serveur.' });
    }
};

// ----------------------
// Rêcuperer tous les utilisateurs (Admin/SAV seulement)
// ----------------------
exports.getAllUsers = async (req, res) => {
    try {
        // Pas besoin de vérifier le rôle ici, car nous le ferons au niveau de la route (plus propre)
        const users = await User.find().select('-password');
        res.status(200).json(users);
    } catch (error) {
        res.status(500).json({ error: 'Erreur serveur lors de la récupération des utilisateurs.' });
    }
};

// ----------------------
// Mettre à jour un utilisateur (y compris son propre profil)
// ----------------------
exports.updateUser = async (req, res) => {
    try {
        const userIdToUpdate = req.params.id;
        const requestingUser = req.auth;
        let updateData = req.body;

        // 1. Contrôle d'autorisation
        // Un utilisateur ne peut modifier que son propre profil, sauf s'il est Admin.
        if (userIdToUpdate !== requestingUser.userId.toString() && requestingUser.role !== 'admin') {
            return res.status(403).json({ error: 'Accès refusé. Vous ne pouvez modifier que votre propre profil.' });
        }

        // 2. Gestion du mot de passe
        if (updateData.password) {
            updateData.password = await bcrypt.hash(updateData.password, 10);
        } else {
            // Empêcher la modification du rôle si l'utilisateur n'est pas Admin
            if (updateData.role && requestingUser.role !== 'admin') {
                delete updateData.role;
            }
        }

        // 3. Exécution de la mise à jour
        const updatedUser = await User.findByIdAndUpdate(
            userIdToUpdate,
            { $set: updateData },
            { new: true, runValidators: true } // new: true retourne le document mis à jour
        ).select('-password');

        if (!updatedUser) {
            return res.status(404).json({ error: 'Utilisateur non trouvé pour la mise à jour.' });
        }

        res.status(200).json({
            message: 'Profil mis à jour avec succès.',
            user: updatedUser
        });

    } catch (error) {
        res.status(500).json({ error: 'Erreur lors de la mise à jour.' });
    }
};

// ----------------------
// Supprimer un utilisateur (Admin seulement)
// ----------------------
exports.deleteUser = async (req, res) => {
    try {
        // Le contrôle du rôle 'admin' sera fait au niveau de la route.
        const deletedUser = await User.findByIdAndDelete(req.params.id);

        if (!deletedUser) {
            return res.status(404).json({ error: 'Utilisateur non trouvé à supprimer.' });
        }

        res.status(200).json({ message: 'Utilisateur supprimé avec succès.' });
    } catch (error) {
        res.status(500).json({ error: 'Erreur lors de la suppression.' });
    }
};