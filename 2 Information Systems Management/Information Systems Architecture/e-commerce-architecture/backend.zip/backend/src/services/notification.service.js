const nodemailer = require('nodemailer');

// Configuration du transporteur d'email
// ATTENTION : Pour une démo locale, vous pouvez utiliser un service de test comme Ethereal.email
// Pour la production, utilisez SendGrid, Mailgun, ou un compte Gmail configuré pour les applications.
const transporter = nodemailer.createTransport({
    host: 'smtp.ethereal.email',
    port: 587,
    auth: {
        user: 'christopher26@ethereal.email',
        pass: 'dq6pcchqjzuS2zk1j5'
    }
});

exports.sendComplaintStatusUpdate = async (userEmail, complaintId, newStatus) => {
    try {
        const mailOptions = {
            from: 'support@ecommerce.com',
            to: userEmail,
            subject: `Mise à jour de votre réclamation #${complaintId}`,
            html: `
                <p>Bonjour,</p>
                <p>Le statut de votre réclamation (ID : <b>${complaintId}</b>) a été mis à jour.</p>
                <p>Nouveau statut : <b>${newStatus}</b></p>
                <p>Notre équipe SAV est dessus !</p>
            `,
        };

        const info = await transporter.sendMail(mailOptions);
        console.log(`Notification envoyée à ${userEmail}. ID message: ${info.messageId}`);

    } catch (error) {
        console.error('Erreur lors de l\'envoi de la notification:', error);
        // Ne pas renvoyer d'erreur 500 au client si la notification échoue
    }
};

