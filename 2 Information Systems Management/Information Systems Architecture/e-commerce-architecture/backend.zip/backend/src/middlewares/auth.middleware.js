const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
    try {
        // 1. Récupérer le token depuis l'en-tête Authorization
        // L'en-tête est généralement au format 'Bearer <token>'
        const token = req.headers.authorization.split(' ')[1];

        // 2. Décoder le token en utilisant la même clé secrète que pour la création (auth.controller.js)
        // ATTENTION : Utilisez la même clé secrète !
        const decodedToken = jwt.verify(token, 'RANDOM_TOKEN_SECRET_CHANGE_ME_IN_PROD');

        // 3. Récupérer l'ID utilisateur et le rôle du payload décodé
        const { userId, role } = decodedToken;

        // 4. Ajouter l'ID utilisateur et le rôle à l'objet requête (pour usage ultérieur dans les contrôleurs)
        req.auth = {
            userId: userId,
            role: role
        };

        // 5. Passer à la fonction middleware ou au contrôleur suivant
        next();

    } catch (error) {
        // En cas d'erreur (token manquant, invalide ou expiré)
        res.status(401).json({
            error: 'Requête non authentifiée !'
        });
    }
};