// role.middleware.js
module.exports = (allowedRoles) => {
    return (req, res, next) => {
        // Le rôle est attaché par auth.middleware.js (dans req.auth.role)
        const userRole = req.auth && req.auth.role;

        // 1. Vérifier si l'utilisateur est authentifié
        if (!userRole) {
            return res.status(401).json({ error: 'Accès refusé. Non authentifié.' });
        }

        // 2. Vérifier si le rôle de l'utilisateur est inclus dans les rôles autorisés
        if (allowedRoles.includes(userRole)) {
            next(); // Rôle autorisé, on continue
        } else {
            // Rôle non autorisé
            return res.status(403).json({ error: 'Accès refusé. Droits insuffisants.' });
        }
    };
};