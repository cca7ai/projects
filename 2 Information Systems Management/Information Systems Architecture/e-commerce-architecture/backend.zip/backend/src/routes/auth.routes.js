const express = require('express');
const router = express.Router(); // Crée un routeur Express
const authController = require('../controllers/auth.controller'); // Importe le contrôleur

// POST /api/auth/signup
router.post('/signup', authController.signup);

// POST /api/auth/login
router.post('/login', authController.login);

module.exports = router;