const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/auth.middleware');
const commentController = require('../controllers/comment.controller');

// ----------------------------------------------------
// POST /api/comments/:complaintId
// Création : Accès par Client (sa plainte), SAV, ou Admin
// ----------------------------------------------------
router.post('/:complaintId', authMiddleware, commentController.createComment);

// ----------------------------------------------------
// GET /api/comments/:complaintId
// Lecture de l'historique : Accès par Client (sa plainte), SAV, ou Admin
// ----------------------------------------------------
router.get('/:complaintId', authMiddleware, commentController.getCommentsByComplaint);

module.exports = router;