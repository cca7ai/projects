const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const authMiddleware = require('../middlewares/auth.middleware');
const roleMiddleware = require('../middlewares/role.middleware'); // Import du nouveau middleware

// Rôles autorisés pour les opérations sensibles
const ROLES_ADMIN_SAV = ['admin', 'sav'];
const ROLES_ADMIN = ['admin'];

// ----------------------------------------------------
// GET /api/users/
// Accès : Admin et SAV seulement (pour l'affichage de listes)
// ----------------------------------------------------
router.get('/', authMiddleware, roleMiddleware(ROLES_ADMIN_SAV), userController.getAllUsers);

// ----------------------------------------------------
// GET /api/users/:id
// Accès : Authentifié (peut voir son propre profil) + Admin/SAV (peut voir tous les profils)
// ----------------------------------------------------
router.get('/:id', authMiddleware, userController.getOneUser);

// ----------------------------------------------------
// PUT /api/users/:id
// Accès : Authentifié (pour modifier son propre profil) + Admin (pour modifier tout le monde)
// ----------------------------------------------------
router.put('/:id', authMiddleware, userController.updateUser);

// ----------------------------------------------------
// DELETE /api/users/:id
// Accès : Admin seulement
// ----------------------------------------------------
router.delete('/:id', authMiddleware, roleMiddleware(ROLES_ADMIN), userController.deleteUser);

module.exports = router;