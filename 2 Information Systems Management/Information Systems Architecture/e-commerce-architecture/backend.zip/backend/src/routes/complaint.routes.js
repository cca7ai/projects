const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/auth.middleware'); // Import du middleware
const roleMiddleware = require('../middlewares/role.middleware');
const complaintController = require('../controllers/complaint.controller');

// La route POST pour la création d'une réclamation
// Le middleware authMiddleware est exécuté avant le contrôleur.
// S'il échoue, le contrôleur ne sera jamais appelé.
router.post('/', authMiddleware, complaintController.createComplaint);

// Exemple de route sécurisée pour lister les réclamations d'un client
// router.get('/', authMiddleware, complaintController.getClientComplaints);

// Rôles autorisés pour la gestion
const ROLES_ADMIN_SAV = ['admin', 'sav'];

// ----------------------------------------------------
// POST /api/complaints/
// Création : Accès par les Clients seulement
// ----------------------------------------------------
router.post('/', authMiddleware, roleMiddleware(['client']), complaintController.createComplaint);

// ----------------------------------------------------
// GET /api/complaints/
// Liste : Accès par tous les utilisateurs authentifiés (filtré dans le contrôleur)
// ----------------------------------------------------
router.get('/', authMiddleware, complaintController.getComplaints);

// ----------------------------------------------------
// GET /api/complaints/:id
// Détail : Accès par l'utilisateur propriétaire, SAV, ou Admin.
// ----------------------------------------------------
router.get('/:id', authMiddleware, complaintController.getOneComplaint);

// ----------------------------------------------------
// PUT /api/complaints/:id
// Modification/Statut : Accès par SAV ou Admin seulement
// ----------------------------------------------------
router.put('/:id', authMiddleware, roleMiddleware(ROLES_ADMIN_SAV), complaintController.updateComplaint);

module.exports = router;