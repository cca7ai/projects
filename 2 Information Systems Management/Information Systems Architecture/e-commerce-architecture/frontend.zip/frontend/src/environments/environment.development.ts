export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000/api' // L'URL de base de votre API Express
};
