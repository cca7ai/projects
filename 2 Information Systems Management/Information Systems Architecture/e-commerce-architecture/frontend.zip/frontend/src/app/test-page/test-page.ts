import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { Card } from '../shared/components';

@Component({
  selector: 'app-test-page',
  standalone: true,
  imports: [CommonModule, Card],
  template: `
    <div class="test-page">
      <h1>{{ title }}</h1>
      <app-card>
        <p>{{ description }}</p>
        <p style="color: #6c757d; margin-top: 16px; font-size: 14px;">
          📝 Cette page sera développée dans les prochaines étapes.
        </p>
      </app-card>
    </div>
  `,
  styles: [`
    .test-page {
      padding: 40px;
      max-width: 1200px;
      margin: 0 auto;

      h1 {
        margin: 0 0 24px 0;
        color: #212529;
      }

      p {
        margin: 0;
        line-height: 1.6;
      }
    }
  `]
})
export class TestPage {
  title: string = '';
  description: string = '';

  constructor(private route: ActivatedRoute) {
    this.route.data.subscribe(data => {
      this.title = data['title'] || 'Page';
      this.description = data['description'] || 'Contenu à venir';
    });
  }
}
