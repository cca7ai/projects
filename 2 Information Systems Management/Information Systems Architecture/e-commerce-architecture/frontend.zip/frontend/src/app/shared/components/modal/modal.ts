import { Component, input, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Button } from '../button/button';

@Component({
  selector: 'app-modal',
  standalone: true,
  imports: [CommonModule, Button],
  templateUrl: './modal.html',
  styleUrls: ['./modal.scss']
})
export class Modal {
  // Inputs
  title = input<string>('');
  isOpen = input<boolean>(false);
  showFooter = input<boolean>(true);
  confirmLabel = input<string>('Confirmer');
  cancelLabel = input<string>('Annuler');
  confirmVariant = input<'primary' | 'danger'>('primary');

  // Outputs
  closed = output<void>();
  confirmed = output<void>();
  cancelled = output<void>();

  onClose(): void {
    this.closed.emit();
  }

  onConfirm(): void {
    this.confirmed.emit();
  }

  onCancel(): void {
    this.cancelled.emit();
  }

  onBackdropClick(event: MouseEvent): void {
    if (event.target === event.currentTarget) {
      this.onClose();
    }
  }
}
