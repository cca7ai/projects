import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-badge',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './badge.html',
  styleUrls: ['./badge.scss']
})
export class Badge {
  label = input.required<string>();
  variant = input<'success' | 'warning' | 'danger' | 'info' | 'default'>('default');
  size = input<'small' | 'medium'>('medium');
}
