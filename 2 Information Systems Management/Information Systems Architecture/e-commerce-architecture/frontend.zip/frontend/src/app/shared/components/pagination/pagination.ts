import { Component, input, output, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-pagination',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pagination.html',
  styleUrls: ['./pagination.scss']
})
export class Pagination {
  // Inputs
  currentPage = input.required<number>();
  totalPages = input.required<number>();
  totalItems = input<number>(0);
  itemsPerPage = input<number>(10);
  showInfo = input<boolean>(true);
  maxVisiblePages = input<number>(5);

  // Outputs
  pageChanged = output<number>();

  // Computed
  pages = computed(() => {
    const total = this.totalPages();
    const current = this.currentPage();
    const max = this.maxVisiblePages();

    if (total <= max) {
      return Array.from({ length: total }, (_, i) => i + 1);
    }

    const half = Math.floor(max / 2);
    let start = Math.max(1, current - half);
    let end = Math.min(total, start + max - 1);

    if (end - start < max - 1) {
      start = Math.max(1, end - max + 1);
    }

    return Array.from({ length: end - start + 1 }, (_, i) => start + i);
  });

  hasPrevious = computed(() => this.currentPage() > 1);
  hasNext = computed(() => this.currentPage() < this.totalPages());

  startItem = computed(() => {
    const current = this.currentPage();
    const perPage = this.itemsPerPage();
    return (current - 1) * perPage + 1;
  });

  endItem = computed(() => {
    const current = this.currentPage();
    const perPage = this.itemsPerPage();
    const total = this.totalItems();
    const end = current * perPage;
    return Math.min(end, total);
  });

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages() && page !== this.currentPage()) {
      this.pageChanged.emit(page);
    }
  }

  previousPage(): void {
    if (this.hasPrevious()) {
      this.goToPage(this.currentPage() - 1);
    }
  }

  nextPage(): void {
    if (this.hasNext()) {
      this.goToPage(this.currentPage() + 1);
    }
  }

  firstPage(): void {
    this.goToPage(1);
  }

  lastPage(): void {
    this.goToPage(this.totalPages());
  }
}
