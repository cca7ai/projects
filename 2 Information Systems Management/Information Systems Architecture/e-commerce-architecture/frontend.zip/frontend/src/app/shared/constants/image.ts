export const DEFAULT_IMAGES = {
  logo: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='40' height='40' viewBox='0 0 40 40'%3E%3Crect width='40' height='40' rx='8' fill='%23007bff'/%3E%3Cpath d='M20 10L30 25H10L20 10Z' fill='white'/%3E%3C/svg%3E`,

  categoryElectronics: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='200' viewBox='0 0 300 200'%3E%3Crect width='300' height='200' fill='%23667eea'/%3E%3Ctext x='150' y='100' font-family='Arial' font-size='24' font-weight='bold' fill='white' text-anchor='middle' dominant-baseline='middle'%3EÉlectronique%3C/text%3E%3C/svg%3E`,

  categoryClothing: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='200' viewBox='0 0 300 200'%3E%3Crect width='300' height='200' fill='%23f093fb'/%3E%3Ctext x='150' y='100' font-family='Arial' font-size='24' font-weight='bold' fill='white' text-anchor='middle' dominant-baseline='middle'%3EVêtements%3C/text%3E%3C/svg%3E`,

  categoryHome: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='200' viewBox='0 0 300 200'%3E%3Crect width='300' height='200' fill='%234facfe'/%3E%3Ctext x='150' y='100' font-family='Arial' font-size='24' font-weight='bold' fill='white' text-anchor='middle' dominant-baseline='middle'%3EMaison%3C/text%3E%3C/svg%3E`,

  categorySports: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='200' viewBox='0 0 300 200'%3E%3Crect width='300' height='200' fill='%2343e97b'/%3E%3Ctext x='150' y='100' font-family='Arial' font-size='24' font-weight='bold' fill='white' text-anchor='middle' dominant-baseline='middle'%3ESports%3C/text%3E%3C/svg%3E`,

  // Images produits détaillées
  products: {
    smartphone: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect width='400' height='400' fill='%23667eea'/%3E%3Crect x='120' y='50' width='160' height='280' rx='20' fill='%23fff'/%3E%3Crect x='135' y='70' width='130' height='220' fill='%23667eea'/%3E%3Ccircle cx='200' cy='310' r='15' fill='%23667eea'/%3E%3C/svg%3E`,

    headphones: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect width='400' height='400' fill='%23f093fb'/%3E%3Cpath d='M200 100 Q120 100 120 180 L120 260 Q120 280 140 280 L160 280 L160 180 Q160 140 200 140 Q240 140 240 180 L240 280 L260 280 Q280 280 280 260 L280 180 Q280 100 200 100 Z' fill='%23fff'/%3E%3C/svg%3E`,

    keyboard: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect width='400' height='400' fill='%234facfe'/%3E%3Crect x='80' y='150' width='240' height='120' rx='10' fill='%23fff'/%3E%3Crect x='100' y='170' width='30' height='15' rx='2' fill='%234facfe'/%3E%3Crect x='140' y='170' width='30' height='15' rx='2' fill='%234facfe'/%3E%3Crect x='180' y='170' width='30' height='15' rx='2' fill='%234facfe'/%3E%3Crect x='220' y='170' width='30' height='15' rx='2' fill='%234facfe'/%3E%3Crect x='260' y='170' width='30' height='15' rx='2' fill='%234facfe'/%3E%3Crect x='100' y='200' width='30' height='15' rx='2' fill='%234facfe'/%3E%3Crect x='140' y='200' width='30' height='15' rx='2' fill='%234facfe'/%3E%3Crect x='180' y='200' width='30' height='15' rx='2' fill='%234facfe'/%3E%3Crect x='220' y='200' width='30' height='15' rx='2' fill='%234facfe'/%3E%3Crect x='260' y='200' width='30' height='15' rx='2' fill='%234facfe'/%3E%3Crect x='120' y='230' width='160' height='20' rx='5' fill='%234facfe'/%3E%3C/svg%3E`,

    tshirt: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect width='400' height='400' fill='%2343e97b'/%3E%3Cpath d='M150 120 L130 140 L130 200 L150 200 L150 320 L250 320 L250 200 L270 200 L270 140 L250 120 L230 100 L170 100 Z' fill='%23fff'/%3E%3Ccircle cx='200' cy='130' r='15' fill='%2343e97b'/%3E%3C/svg%3E`,

    watch: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect width='400' height='400' fill='%23ffd89b'/%3E%3Crect x='140' y='80' width='120' height='30' rx='15' fill='%23555'/%3E%3Crect x='130' y='110' width='140' height='180' rx='20' fill='%23333'/%3E%3Crect x='140' y='120' width='120' height='160' rx='10' fill='%23000'/%3E%3Crect x='140' y='290' width='120' height='30' rx='15' fill='%23555'/%3E%3Cline x1='200' y1='200' x2='200' y2='160' stroke='%2300ff00' stroke-width='3'/%3E%3Cline x1='200' y1='200' x2='230' y2='200' stroke='%2300ff00' stroke-width='2'/%3E%3C/svg%3E`,

    chair: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect width='400' height='400' fill='%23a8edea'/%3E%3Crect x='120' y='120' width='160' height='100' rx='10' fill='%23555'/%3E%3Crect x='130' y='220' width='140' height='10' fill='%23444'/%3E%3Crect x='130' y='230' width='20' height='120' fill='%23333'/%3E%3Crect x='250' y='230' width='20' height='120' fill='%23333'/%3E%3Crect x='120' y='80' width='20' height='40' fill='%23444'/%3E%3Crect x='260' y='80' width='20' height='40' fill='%23444'/%3E%3C/svg%3E`
  },

  // Placeholder générique
  productPlaceholder: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect width='400' height='400' fill='%23e9ecef'/%3E%3Ccircle cx='200' cy='180' r='50' fill='%23adb5bd'/%3E%3Crect x='150' y='240' width='100' height='80' rx='4' fill='%23adb5bd'/%3E%3Ctext x='200' y='350' font-family='Arial' font-size='16' fill='%236c757d' text-anchor='middle'%3EProduit%3C/text%3E%3C/svg%3E`
};
