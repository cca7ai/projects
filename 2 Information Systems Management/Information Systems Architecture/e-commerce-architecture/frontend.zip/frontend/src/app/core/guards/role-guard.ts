import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  constructor(
    private router: Router,
    private authService: AuthService
  ) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
    const currentUser = this.authService.currentUserValue;
    const allowedRoles = route.data['roles'] as string[];

    if (currentUser && allowedRoles.includes(currentUser.role)) {
      return true;
    }

    // Pas le bon rôle
    this.router.navigate(['/']);
    return false;
  }
}
