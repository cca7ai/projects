export enum UserRole {
  CLIENT = 'client',
  SAV = 'sav',
  ADMIN = 'admin'
}
