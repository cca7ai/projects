import { Injectable, inject, PLATFORM_ID, signal, computed } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { User } from '../models/user.model';
import { UserRole } from '../models/role.enum';
import { ApiResponse } from '../models/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private platformId = inject(PLATFORM_ID);
  private isBrowser: boolean;
  private http = inject(HttpClient);
  private router = inject(Router);

  private currentUserSignal = signal<User | null>(null);
  public currentUser = this.currentUserSignal.asReadonly();
  public isAuthenticated = computed(() => !!this.currentUserSignal());

  private apiUrl = 'http://localhost:3000/api';

  constructor() {
    this.isBrowser = isPlatformBrowser(this.platformId);

    // Charger l'utilisateur depuis localStorage
    if (this.isBrowser) {
      const userJson = localStorage.getItem('currentUser');
      if (userJson) {
        this.currentUserSignal.set(JSON.parse(userJson));
      }
    }
  }

  public get currentUserValue(): User | null {
    return this.currentUserSignal();
  }

  // TEMPORAIRE : Connexion simulée pour la démo
  simulateLogin(email: string, role: UserRole): void {
    const mockUser: User = {
      id: Date.now().toString(),
      email: email,
      firstName: 'Jean',
      lastName: 'Dupont',
      role: role,
      token: 'mock-token-' + Date.now()
    };

    if (this.isBrowser) {
      localStorage.setItem('currentUser', JSON.stringify(mockUser));
    }

    this.currentUserSignal.set(mockUser);
  }

  // Vraie méthode login (à utiliser avec le backend)
  login(email: string, password: string): Observable<ApiResponse<User>> {
    return this.http.post<ApiResponse<User>>(`${this.apiUrl}/auth/login`, { email, password })
      .pipe(
        tap(response => {
          if (response.success && response.data) {
            if (this.isBrowser) {
              localStorage.setItem('currentUser', JSON.stringify(response.data));
            }
            this.currentUserSignal.set(response.data);
          }
        })
      );
  }

  logout(): void {
    if (this.isBrowser) {
      localStorage.removeItem('currentUser');
    }
    this.currentUserSignal.set(null);
    this.router.navigate(['/login']);
  }

  register(userData: any): Observable<ApiResponse<User>> {
    return this.http.post<ApiResponse<User>>(`${this.apiUrl}/auth/register`, userData);
  }
}
