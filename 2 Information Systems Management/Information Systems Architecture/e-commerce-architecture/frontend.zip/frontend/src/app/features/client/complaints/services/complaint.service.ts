import { Injectable, signal } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import { Observable, of, delay } from 'rxjs';
import { Complaint, CreateComplaintDto, ComplaintComment } from '../models/complaint.model';
import { ComplaintStatus, ComplaintType, ComplaintPriority } from '../models/complaint-status.enum';
import { environment } from '../../../../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})
export class ComplaintService {
  private apiUrl = `${environment.apiUrl}`;
  // Signal pour stocker les réclamations localement
  private complaintsSignal = signal<Complaint[]>([]);
  public complaints = this.complaintsSignal.asReadonly();

  constructor(private http: HttpClient) {
    this.loadMockData();
  }

  // TEMPORAIRE : Données mockées

  private loadMockData(): void {
    const mockComplaints: Complaint[] = [
      {
        id: '1',
        orderId: 'ORD-2024-001',
        orderNumber: '#12345',
        productId: 'PROD-001',
        productName: 'Smartphone XYZ Pro',
        productImage: 'https://via.placeholder.com/100',
        userId: '1',
        type: ComplaintType.DEFECT,
        description: 'L\'écran du smartphone présente des pixels morts dans le coin supérieur droit. Le problème est apparu après 3 jours d\'utilisation.',
        priority: ComplaintPriority.HIGH,
        status: ComplaintStatus.IN_PROGRESS,
        assignedTo: 'sav-001',
        assignedToName: 'Marie Martin',
        comments: [
          {
            id: 'c1',
            userId: 'sav-001',
            userName: 'Marie Martin',
            userRole: 'SAV',
            text: 'Bonjour, nous avons bien pris en compte votre réclamation. Pouvez-vous nous envoyer une photo du défaut ?',
            createdAt: new Date('2024-11-18T10:30:00')
          }
        ],
        createdAt: new Date('2024-11-17T14:20:00'),
        updatedAt: new Date('2024-11-18T10:30:00')
      },
      {
        id: '2',
        orderId: 'ORD-2024-002',
        orderNumber: '#12346',
        productId: 'PROD-002',
        productName: 'Casque Audio Bluetooth',
        productImage: 'https://via.placeholder.com/100',
        userId: '1',
        type: ComplaintType.DELAY,
        description: 'Ma commande devait arriver le 15 novembre mais je n\'ai toujours rien reçu. Le suivi indique "en transit" depuis 5 jours.',
        priority: ComplaintPriority.MEDIUM,
        status: ComplaintStatus.RESOLVED,
        resolution: 'Votre colis a été livré le 19 novembre. Nous nous excusons pour le retard.',
        createdAt: new Date('2024-11-16T09:15:00'),
        updatedAt: new Date('2024-11-19T16:45:00'),
        resolvedAt: new Date('2024-11-19T16:45:00')
      },
      {
        id: '3',
        orderId: 'ORD-2024-003',
        orderNumber: '#12347',
        productId: 'PROD-003',
        productName: 'Clavier Mécanique RGB',
        userId: '1',
        type: ComplaintType.DAMAGED,
        description: 'Le colis est arrivé endommagé, la boîte était ouverte et le clavier a plusieurs touches qui ne fonctionnent pas.',
        priority: ComplaintPriority.HIGH,
        status: ComplaintStatus.OPEN,
        createdAt: new Date('2024-11-20T08:00:00'),
        updatedAt: new Date('2024-11-20T08:00:00')
      }
    ];

    this.complaintsSignal.set(mockComplaints);
  }

  // Récupérer toutes les réclamations du client
  getMyComplaints(filters?: {
    status?: ComplaintStatus;
    type?: ComplaintType;
    page?: number;
    limit?: number;
  }): Observable<{ complaints: Complaint[], total: number }> {
    // TEMPORAIRE : Filtrer les données mockées
    let filtered = [...this.complaintsSignal()];

    if (filters?.status) {
      filtered = filtered.filter(c => c.status === filters.status);
    }

    if (filters?.type) {
      filtered = filtered.filter(c => c.type === filters.type);
    }

    return of({
      complaints: filtered,
      total: filtered.length
    }).pipe(delay(500));

    /*VERSION AVEC API :
    /*
    const params = new HttpParams({ fromObject: filters as any });
    return this.http.get<{ complaints: Complaint[], total: number }>(
      `${this.apiUrl}/complaints`,
      { params }
    );
    */
  }

  // Récupérer une réclamation par ID
  getComplaintById(id: string): Observable<Complaint | null> {
    const complaint = this.complaintsSignal().find(c => c.id === id);
    //return of(complaint || null).pipe(delay(300));
    return this.http.get<Complaint>(`${this.apiUrl}/complaints/${id}`);

    /* VERSION AVEC API :
    return this.http.get<Complaint>(`${this.apiUrl}/${id}`);
    */
  }

  // Créer une nouvelle réclamation
  createComplaint(data: CreateComplaintDto): Observable<Complaint> {
    // TEMPORAIRE : Créer une réclamation mockée
    /*
    const newComplaint: Complaint = {
      id: Date.now().toString(),
      orderId: data.orderId,
      orderNumber: '#' + Math.floor(Math.random() * 90000 + 10000),
      productId: data.productId,
      productName: 'Produit Example',
      productImage: 'https://via.placeholder.com/100',
      userId: '1',
      type: data.type,
      description: data.description,
      priority: data.priority || ComplaintPriority.MEDIUM,
      status: ComplaintStatus.OPEN,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    // Ajouter au signal
    this.complaintsSignal.update(complaints => [newComplaint, ...complaints]);

    return of(newComplaint).pipe(delay(1000));
    */
    // VERSION AVEC API :
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (key === 'attachments' && data.attachments) {
        data.attachments.forEach(file => {
          formData.append('attachments', file);
        });
      } else {
        formData.append(key, (data as any)[key]);
      }
    });
    return this.http.post<Complaint>(this.apiUrl, formData);

  }

  // Ajouter un commentaire
  addComment(complaintId: string, text: string): Observable<ComplaintComment> {
    /*
    const newComment: ComplaintComment = {
      id: Date.now().toString(),
      userId: '1',
      userName: 'Messadi MEHDI',
      userRole: 'Client',
      text: text,
      createdAt: new Date()
    };

    // Mettre à jour le signal
    this.complaintsSignal.update(complaints =>
      complaints.map(c => {
        if (c.id === complaintId) {
          return {
            ...c,
            comments: [...(c.comments || []), newComment],
            updatedAt: new Date()
          };
        }
        return c;
      })
    );

    //return of(newComment).pipe(delay(500));
  */
    //VERSION AVEC API :
    return this.http.post<ComplaintComment>(
      //`${this.apiUrl}/${complaintId}/comment`,
      `${this.apiUrl}/comments/${complaintId}`,
      { content: text }
    );

  }

  // Statistiques pour le dashboard
  getStats(): Observable<{
    total: number;
    open: number;
    inProgress: number;
    resolved: number;
    closed: number;
  }> {
    const complaints = this.complaintsSignal();
    return of({
      total: complaints.length,
      open: complaints.filter(c => c.status === ComplaintStatus.OPEN).length,
      inProgress: complaints.filter(c => c.status === ComplaintStatus.IN_PROGRESS).length,
      resolved: complaints.filter(c => c.status === ComplaintStatus.RESOLVED).length,
      closed: complaints.filter(c => c.status === ComplaintStatus.CLOSED).length
    }).pipe(delay(300));
  }

  // Helper : Obtenir le label d'un statut
  getStatusLabel(status: ComplaintStatus): string {
    const labels: Record<ComplaintStatus, string> = {
      [ComplaintStatus.OPEN]: 'Ouverte',
      [ComplaintStatus.IN_PROGRESS]: 'En cours',
      [ComplaintStatus.RESOLVED]: 'Résolue',
      [ComplaintStatus.CLOSED]: 'Fermée',
      [ComplaintStatus.REJECTED]: 'Rejetée'
    };
    return labels[status];
  }

  // Helper : Obtenir la variante du badge pour un statut
  getStatusVariant(status: ComplaintStatus): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    const variants: Record<ComplaintStatus, 'success' | 'warning' | 'danger' | 'info' | 'default'> = {
      [ComplaintStatus.OPEN]: 'info',
      [ComplaintStatus.IN_PROGRESS]: 'warning',
      [ComplaintStatus.RESOLVED]: 'success',
      [ComplaintStatus.CLOSED]: 'default',
      [ComplaintStatus.REJECTED]: 'danger'
    };
    return variants[status];
  }

  // Helper : Obtenir le label d'un type
  getTypeLabel(type: ComplaintType): string {
    const labels: Record<ComplaintType, string> = {
      [ComplaintType.DEFECT]: 'Défaut produit',
      [ComplaintType.DELAY]: 'Retard de livraison',
      [ComplaintType.WRONG_PRODUCT]: 'Mauvais produit',
      [ComplaintType.DAMAGED]: 'Produit endommagé',
      [ComplaintType.OTHER]: 'Autre'
    };
    return labels[type];
  }

  // Helper : Obtenir le label de priorité
  getPriorityLabel(priority: ComplaintPriority): string {
    const labels: Record<ComplaintPriority, string> = {
      [ComplaintPriority.LOW]: 'Basse',
      [ComplaintPriority.MEDIUM]: 'Moyenne',
      [ComplaintPriority.HIGH]: 'Haute'
    };
    return labels[priority];
  }
}
