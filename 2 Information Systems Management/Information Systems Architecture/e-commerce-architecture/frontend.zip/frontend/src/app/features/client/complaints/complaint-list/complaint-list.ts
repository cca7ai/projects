import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ComplaintService } from '../services/complaint.service';
import { Complaint } from '../models/complaint.model';
import { ComplaintStatus, ComplaintType } from '../models/complaint-status.enum';
import { Card } from '../../../../shared/components';
import { Button } from '../../../../shared/components';
import { Badge } from '../../../../shared/components';
import { LoadingSpinner } from '../../../../shared/components';

@Component({
  selector: 'app-complaint-list',
  standalone: true,
  imports: [
    CommonModule,
    Card,
    Button,
    Badge,
    LoadingSpinner
  ],
  templateUrl: './complaint-list.html',
  styleUrls: ['./complaint-list.scss']
})
export class ComplaintList implements OnInit {
  complaints = signal<Complaint[]>([]);
  isLoading = signal(true);
  selectedStatus = signal<ComplaintStatus | 'all'>('all');
  selectedType = signal<ComplaintType | 'all'>('all');

  // Computed pour filtrer les réclamations
  filteredComplaints = computed(() => {
    let filtered = this.complaints();

    if (this.selectedStatus() !== 'all') {
      filtered = filtered.filter(c => c.status === this.selectedStatus());
    }

    if (this.selectedType() !== 'all') {
      filtered = filtered.filter(c => c.type === this.selectedType());
    }

    return filtered;
  });

  // Stats
  stats = computed(() => {
    const all = this.complaints();
    return {
      total: all.length,
      open: all.filter(c => c.status === ComplaintStatus.OPEN).length,
      inProgress: all.filter(c => c.status === ComplaintStatus.IN_PROGRESS).length,
      resolved: all.filter(c => c.status === ComplaintStatus.RESOLVED).length
    };
  });

  constructor(
    private complaintService: ComplaintService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadComplaints();
  }

  loadComplaints(): void {
    this.isLoading.set(true);

    this.complaintService.getMyComplaints().subscribe({
      next: (response) => {
        this.complaints.set(response.complaints);
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('Erreur chargement réclamations:', error);
        this.isLoading.set(false);
      }
    });
  }

  filterByStatus(status: ComplaintStatus | 'all'): void {
    this.selectedStatus.set(status);
  }

  filterByType(type: ComplaintType | 'all'): void {
    this.selectedType.set(type);
  }

  viewDetails(complaintId: string): void {
    this.router.navigate(['/client/complaints', complaintId]);
  }

  createComplaint(): void {
    this.router.navigate(['/client/complaints/new']);
  }

  getStatusLabel(status: ComplaintStatus): string {
    return this.complaintService.getStatusLabel(status);
  }

  getStatusVariant(status: ComplaintStatus): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    return this.complaintService.getStatusVariant(status);
  }

  getTypeLabel(type: ComplaintType): string {
    return this.complaintService.getTypeLabel(type);
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  }

  getTimeAgo(date: Date): string {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) return 'Aujourd\'hui';
    if (days === 1) return 'Hier';
    if (days < 7) return `Il y a ${days} jours`;
    if (days < 30) return `Il y a ${Math.floor(days / 7)} semaines`;
    return `Il y a ${Math.floor(days / 30)} mois`;
  }

  protected readonly status = status;
  protected readonly ComplaintStatus = ComplaintStatus;
}
