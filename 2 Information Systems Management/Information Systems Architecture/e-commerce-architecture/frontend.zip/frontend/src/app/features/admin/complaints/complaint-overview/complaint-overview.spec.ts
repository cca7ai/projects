import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintOverview } from './complaint-overview';

describe('ComplaintOverview', () => {
  let component: ComplaintOverview;
  let fixture: ComponentFixture<ComplaintOverview>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ComplaintOverview]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ComplaintOverview);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
