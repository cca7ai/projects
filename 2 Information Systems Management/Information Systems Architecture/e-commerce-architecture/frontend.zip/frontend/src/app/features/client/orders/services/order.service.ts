import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable, of, delay, map} from 'rxjs';
import { DEFAULT_IMAGES } from '../../../../shared/constants/image';

export interface OrderItem {
  productId: string;
  productName: string;
  productImage: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  items: OrderItem[];
  totalAmount: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  shippingAddress: {
    street: string;
    city: string;
    postalCode: string;
    country: string;
  };
  createdAt: Date;
  updatedAt: Date;
  deliveredAt?: Date;
  trackingNumber?: string;
}

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private apiUrl = 'http://localhost:3000/api/orders';

  constructor(private http: HttpClient) {}

  // Récupérer les commandes du client
  getMyOrders(): Observable<Order[]> {
    // TEMPORAIRE : Données mockées
    const mockOrders: Order[] = [
      {
        id: 'ORD-2024-001',
        orderNumber: '#12345',
        userId: '1',
        items: [
          {
            productId: 'PROD-001',
            productName: 'Smartphone XYZ Pro',
            productImage: DEFAULT_IMAGES.products.smartphone, // ← Mettre à jour
            quantity: 1,
            price: 799.99
          },
          {
            productId: 'PROD-002',
            productName: 'Coque de protection',
            productImage: DEFAULT_IMAGES.productPlaceholder,
            quantity: 1,
            price: 19.99
          }
        ],
        totalAmount: 819.98,
        status: 'delivered',
        shippingAddress: {
          street: '123 Rue de la Paix',
          city: 'Paris',
          postalCode: '75001',
          country: 'France'
        },
        createdAt: new Date('2024-11-10T10:30:00'),
        updatedAt: new Date('2024-11-15T14:20:00'),
        deliveredAt: new Date('2024-11-15T14:20:00'),
        trackingNumber: 'FR123456789'
      },
      {
        id: 'ORD-2024-002',
        orderNumber: '#12346',
        userId: '1',
        items: [
          {
            productId: 'PROD-003',
            productName: 'Casque Audio Bluetooth',
            productImage: DEFAULT_IMAGES.products.headphones,
            quantity: 1,
            price: 149.99
          }
        ],
        totalAmount: 149.99,
        status: 'shipped',
        shippingAddress: {
          street: '123 Rue de la Paix',
          city: 'Paris',
          postalCode: '75001',
          country: 'France'
        },
        createdAt: new Date('2024-11-15T09:15:00'),
        updatedAt: new Date('2024-11-18T16:45:00'),
        trackingNumber: 'FR987654321'
      },
      {
        id: 'ORD-2024-003',
        orderNumber: '#12347',
        userId: '1',
        items: [
          {
            productId: 'PROD-004',
            productName: 'Clavier Mécanique RGB',
            productImage: DEFAULT_IMAGES.products.keyboard,
            quantity: 1,
            price: 129.99
          },
          {
            productId: 'PROD-005',
            productName: 'Souris Gaming',
            productImage: DEFAULT_IMAGES.products.keyboard,
            quantity: 1,
            price: 59.99
          }
        ],
        totalAmount: 189.98,
        status: 'processing',
        shippingAddress: {
          street: '123 Rue de la Paix',
          city: 'Paris',
          postalCode: '75001',
          country: 'France'
        },
        createdAt: new Date('2024-11-18T14:20:00'),
        updatedAt: new Date('2024-11-19T10:30:00')
      }
    ];

    return of(mockOrders).pipe(delay(500));

    /* VERSION AVEC API :
    return this.http.get<Order[]>(`${this.apiUrl}/my-orders`);
    */
  }

  // Récupérer une commande par ID
  getOrderById(id: string): Observable<Order | null> {
    return this.getMyOrders().pipe(
      delay(300),
      map(orders => {
        // Rechercher la commande spécifique dans le tableau
        const foundOrder = orders.find(o => o.id === id);
        // Renvoyer la commande trouvée, ou null si elle n'existe pas
        return foundOrder || null;
      })
    );

    /* VERSION AVEC API :
    return this.http.get<Order>(`${this.apiUrl}/${id}`);
    */
  }

  // Helper : Obtenir le label du statut
  getStatusLabel(status: string): string {
    const labels: Record<string, string> = {
      pending: 'En attente',
      processing: 'En préparation',
      shipped: 'Expédiée',
      delivered: 'Livrée',
      cancelled: 'Annulée'
    };
    return labels[status] || status;
  }

  // Helper : Obtenir la variante du badge
  getStatusVariant(status: string): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    const variants: Record<string, 'success' | 'warning' | 'danger' | 'info' | 'default'> = {
      pending: 'warning',
      processing: 'info',
      shipped: 'info',
      delivered: 'success',
      cancelled: 'danger'
    };
    return variants[status] || 'default';
  }
}
