import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { SavService } from '../../services/sav.service';
import { Complaint } from '../../../client/complaints/models/complaint.model';
import { ComplaintStatus } from '../../../client/complaints/models/complaint-status.enum';
import { Card } from '../../../../shared/components';
import { Button } from '../../../../shared/components';
import { Badge } from '../../../../shared/components';
import { LoadingSpinner } from '../../../../shared/components';
import { ComplaintService } from '../../../client/complaints/services/complaint.service';

@Component({
  selector: 'app-complaint-queue',
  standalone: true,
  imports: [
    CommonModule,
    Card,
    Button,
    Badge,
    LoadingSpinner
  ],
  templateUrl: './complaint-queue.html',
  styleUrls: ['./complaint-queue.scss']
})
export class ComplaintQueue implements OnInit {
  complaints = signal<Complaint[]>([]);
  isLoading = signal(true);
  selectedFilter = signal<'all' | 'unassigned' | 'mine' | 'high'>('all');
  selectedStatus = signal<ComplaintStatus | 'all'>('all');

  // Computed pour filtrer
  filteredComplaints = computed(() => {
    let filtered = this.complaints();

    // Filtre par assignation
    switch (this.selectedFilter()) {
      case 'unassigned':
        filtered = filtered.filter(c => !c.assignedTo);
        break;
      case 'mine':
        filtered = filtered.filter(c => c.assignedTo === 'sav-001');
        break;
      case 'high':
        filtered = filtered.filter(c => c.priority === 'high');
        break;
    }

    // Filtre par statut
    if (this.selectedStatus() !== 'all') {
      filtered = filtered.filter(c => c.status === this.selectedStatus());
    }

    return filtered;
  });

  // Stats
  stats = computed(() => {
    const all = this.complaints();
    return {
      total: all.length,
      unassigned: all.filter(c => !c.assignedTo).length,
      assigned: all.filter(c => c.assignedTo).length,
      high: all.filter(c => c.priority === 'high').length
    };
  });

  constructor(
    private savService: SavService,
    private complaintService: ComplaintService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadQueue();
  }loadQueue(): void {
  this.isLoading.set(true);
  this.savService.getComplaintQueue().subscribe({
    next: (complaints) => {
      this.complaints.set(complaints);
      this.isLoading.set(false);
    },
    error: (error) => {
      console.error('Erreur chargement file d\'attente:', error);
      this.isLoading.set(false);
    }
  });
}setFilter(filter: 'all' | 'unassigned' | 'mine' | 'high'): void {
  this.selectedFilter.set(filter);
}setStatusFilter(status: ComplaintStatus | 'all'): void {
  this.selectedStatus.set(status);
}viewComplaint(id: string): void {
  this.router.navigate(['/sav/complaints', id]);
}assignToMe(complaint: Complaint): void {
  //event.stopPropagation();
  this.savService.assignToMe(complaint.id).subscribe({
    next: () => {
      // Recharger la file
      this.loadQueue();
    },
    error: (error) => {
      console.error('Erreur assignation:', error);
    }
  });
  }getStatusLabel(status: string): string {
    return this.complaintService.getStatusLabel(status as any);
  }getStatusVariant(status: string): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    return this.complaintService.getStatusVariant(status as any);
  }getTypeLabel(type: string): string {
    return this.complaintService.getTypeLabel(type as any);
  }getPriorityLabel(priority: string): string {
    return this.complaintService.getPriorityLabel(priority as any);
  }getElapsedTime(date: Date): string {
    return this.savService.getElapsedTime(date);
  }getUrgencyLevel(complaint: Complaint): string {
    return this.savService.getUrgencyLevel(complaint);
  }getPriorityVariant(priority: string): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    const variants: Record<string, 'success' | 'warning' | 'danger'> = {
      high: 'danger',
      medium: 'warning',
      low: 'success'
    };
    return variants[priority] || 'default';
  }

  protected readonly ComplaintStatus = ComplaintStatus;
}

