import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable, of, delay, map} from 'rxjs';
import { DEFAULT_IMAGES } from '../../../../shared/constants/image';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  images?: string[];
  category: string;
  stock: number;
  rating: number;
  reviewCount: number;
  features?: string[];
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  productCount: number;
}

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = 'http://localhost:3000/api/products';

  constructor(private http: HttpClient) {}

  // Récupérer tous les produits
  getProducts(filters?: any): Observable<{ products: Product[]; total: number }> {
    const mockProducts: Product[] = [
      {
        id: 'PROD-001',
        name: 'Smartphone XYZ Pro',
        description: 'Smartphone haut de gamme avec écran OLED 6.5" et caméra 108MP',
        price: 799.99,
        originalPrice: 999.99,
        image: DEFAULT_IMAGES.products.smartphone, // ← Utiliser l'image
        images: [DEFAULT_IMAGES.products.smartphone],
        category: 'electronics',
        stock: 25,
        rating: 4.5,
        reviewCount: 128,
        features: ['Écran OLED 6.5"', '128GB stockage', '5G', 'Charge rapide']
      },
      {
        id: 'PROD-002',
        name: 'Casque Audio Bluetooth',
        description: 'Casque sans fil avec réduction de bruit active',
        price: 149.99,
        image: DEFAULT_IMAGES.products.headphones,
        category: 'electronics',
        stock: 50,
        rating: 4.7,
        reviewCount: 89
      },
      {
        id: 'PROD-003',
        name: 'Clavier Mécanique RGB',
        description: 'Clavier gaming avec switches mécaniques et rétroéclairage RGB',
        price: 129.99,
        image: DEFAULT_IMAGES.products.keyboard,
        category: 'electronics',
        stock: 15,
        rating: 4.3,
        reviewCount: 56
      },
      {
        id: 'PROD-004',
        name: 'T-Shirt Premium Coton',
        description: 'T-shirt 100% coton bio, coupe ajustée',
        price: 29.99,
        image: DEFAULT_IMAGES.products.tshirt,
        category: 'clothing',
        stock: 100,
        rating: 4.6,
        reviewCount: 234
      },
      {
        id: 'PROD-005',
        name: 'Montre Connectée Sport',
        description: 'Montre intelligente avec suivi fitness et notifications',
        price: 199.99,
        originalPrice: 249.99,
        image: DEFAULT_IMAGES.products.watch,
        category: 'electronics',
        stock: 30,
        rating: 4.4,
        reviewCount: 167
      },
      {
        id: 'PROD-006',
        name: 'Chaise de Bureau Ergonomique',
        description: 'Chaise de bureau avec soutien lombaire et accoudoirs réglables',
        price: 249.99,
        image: DEFAULT_IMAGES.products.chair,
        category: 'home',
        stock: 12,
        rating: 4.8,
        reviewCount: 92
      }
    ];

    let filtered = mockProducts;

    if (filters?.category) {
      filtered = filtered.filter(p => p.category === filters.category);
    }

    if (filters?.search) {
      const search = filters.search.toLowerCase();
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(search) ||
        p.description.toLowerCase().includes(search)
      );
    }

    if (filters?.minPrice) {
      filtered = filtered.filter(p => p.price >= filters.minPrice!);
    }

    if (filters?.maxPrice) {
      filtered = filtered.filter(p => p.price <= filters.maxPrice!);
    }

    return of({
      products: filtered,
      total: filtered.length
    }).pipe(delay(500));

    /* VERSION AVEC API :
    const params = new HttpParams({ fromObject: filters as any });
    return this.http.get<{ products: Product[]; total: number }>(
      this.apiUrl,
      { params }
    );
    */
  }

  // Récupérer un produit par ID
  getProductById(id: string): Observable<Product | null> {
    return this.getProducts().pipe(
      delay(300),
      // Extraire le produit de la réponse
      map(response => {
        // Rechercher le produit dans le tableau 'products'
        const foundProduct = response.products.find(p => p.id === id);
        // Renvoyer le produit trouvé, ou null s'il n'existe pas
        return foundProduct || null;
      })
    );

    /* VERSION AVEC API :
    return this.http.get<Product>(`${this.apiUrl}/${id}`);
    */
  }

  // Récupérer les catégories
  getCategories(): Observable<Category[]> {
    const mockCategories: Category[] = [
      { id: 'electronics', name: 'Électronique', icon: '📱', productCount: 156 },
      { id: 'clothing', name: 'Vêtements', icon: '👕', productCount: 243 },
      { id: 'home', name: 'Maison', icon: '🏠', productCount: 189 },
      { id: 'sports', name: 'Sports', icon: '⚽', productCount: 127 }
    ];

    return of(mockCategories).pipe(delay(300));

    /* VERSION AVEC API :
    return this.http.get<Category[]>(`${this.apiUrl}/categories`);
    */
  }
}
