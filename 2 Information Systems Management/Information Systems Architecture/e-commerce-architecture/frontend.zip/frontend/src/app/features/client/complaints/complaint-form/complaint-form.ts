import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ComplaintService } from '../services/complaint.service';
import { ComplaintType, ComplaintPriority } from '../models/complaint-status.enum';
import { CreateComplaintDto } from '../models/complaint.model';
import { Card } from '../../../../shared/components';
import { Button } from '../../../../shared/components';
import {ComplaintMockService} from '../services/complaint-mock.service';

interface Order {
  id: string;
  orderNumber: string;
  date: Date;
  products: OrderProduct[];
}

interface OrderProduct {
  id: string;
  name: string;
  image: string;
}

@Component({
  selector: 'app-complaint-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    Card,
    Button,
  ],
  templateUrl: './complaint-form.html',
  styleUrls: ['./complaint-form.scss']
})
export class ComplaintForm {
  // Données mockées des commandes
  orders = signal<Order[]>([
    {
      id: 'ORD-2024-001',
      orderNumber: '#12345',
      date: new Date('2024-11-10'),
      products: [
        { id: 'PROD-001', name: 'Smartphone XYZ Pro', image: 'https://via.placeholder.com/60' },
        { id: 'PROD-002', name: 'Coque de protection', image: 'https://via.placeholder.com/60' }
      ]
    },
    {
      id: 'ORD-2024-002',
      orderNumber: '#12346',
      date: new Date('2024-11-15'),
      products: [
        { id: 'PROD-003', name: 'Casque Audio Bluetooth', image: 'https://via.placeholder.com/60' }
      ]
    },
    {
      id: 'ORD-2024-003',
      orderNumber: '#12347',
      date: new Date('2024-11-18'),
      products: [
        { id: 'PROD-004', name: 'Clavier Mécanique RGB', image: 'https://via.placeholder.com/60' },
        { id: 'PROD-005', name: 'Souris Gaming', image: 'https://via.placeholder.com/60' }
      ]
    }
  ]);

  // Champs du formulaire
  selectedOrderId = signal('');
  selectedProductId = signal('');
  complaintType = signal<ComplaintType | ''>('');
  priority = signal<ComplaintPriority>(ComplaintPriority.MEDIUM);
  description = signal('');
  attachments = signal<File[]>([]);

  // État
  isSubmitting = signal(false);
  errors = signal<Record<string, string>>({});

  // Types et priorités disponibles
  complaintTypes = [
    { value: ComplaintType.DEFECT, label: 'Défaut produit' },
    { value: ComplaintType.DELAY, label: 'Retard de livraison' },
    { value: ComplaintType.WRONG_PRODUCT, label: 'Mauvais produit' },
    { value: ComplaintType.DAMAGED, label: 'Produit endommagé' },
    { value: ComplaintType.OTHER, label: 'Autre' }
  ];

  priorities = [
    { value: ComplaintPriority.LOW, label: 'Basse' },
    { value: ComplaintPriority.MEDIUM, label: 'Moyenne' },
    { value: ComplaintPriority.HIGH, label: 'Haute' }
  ];

  constructor(
    private complaintService: ComplaintService,
    private complaintMockService: ComplaintMockService,
    private router: Router
  ) {}

  get selectedOrder(): Order | undefined {
    return this.orders().find(o => o.id === this.selectedOrderId());
  }

  get selectedProduct(): OrderProduct | undefined {
    return this.selectedOrder?.products.find(p => p.id === this.selectedProductId());
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      const files = Array.from(input.files);

      // Vérifier la taille totale (max 10MB)
      const totalSize = files.reduce((sum, file) => sum + file.size, 0);
      if (totalSize > 10 * 1024 * 1024) {
        this.errors.update(errors => ({
          ...errors,
          attachments: 'La taille totale des fichiers ne doit pas dépasser 10 MB'
        }));
        return;
      }

      this.attachments.set(files);
      this.errors.update(errors => {
        const { attachments, ...rest } = errors;
        return rest;
      });
    }
  }

  removeAttachment(index: number): void {
    this.attachments.update(files => files.filter((_, i) => i !== index));
  }

  validateForm(): boolean {
    const newErrors: Record<string, string> = {};

    if (!this.selectedOrderId()) {
      newErrors['order'] = 'Veuillez sélectionner une commande';
    }

    if (!this.selectedProductId()) {
      newErrors['product'] = 'Veuillez sélectionner un produit';
    }

    if (!this.complaintType()) {
      newErrors['type'] = 'Veuillez sélectionner un type de réclamation';
    }

    if (!this.description().trim()) {
      newErrors['description'] = 'Veuillez décrire votre problème';
    } else if (this.description().length < 20) {
      newErrors['description'] = 'La description doit contenir au moins 20 caractères';
    }

    this.errors.set(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  onSubmit(): void {
    if (!this.validateForm()) {
      return;
    }

    this.isSubmitting.set(true);


    const complaintData: CreateComplaintDto = {
      orderId: this.selectedOrderId(),
      productId: this.selectedProductId(),
      type: this.complaintType() as ComplaintType,
      description: this.description(),
      priority: this.priority(),
      attachments: this.attachments()
    };

    // Utilisez le mock service au lieu du vrai service
    this.complaintMockService.createComplaint(complaintData).subscribe({
      next: (complaint) => {
        this.isSubmitting.set(false);
        this.router.navigate(['/client/complaints', complaint.id]);
      },
      error: (error) => {
        console.error('Erreur création réclamation:', error);
        this.isSubmitting.set(false);
        this.errors.update(errors => ({
          ...errors,
          submit: 'Une erreur est survenue. Veuillez réessayer.'
        }));
      }
    });

    this.complaintService.createComplaint(complaintData).subscribe({
      next: (complaint) => {
        this.isSubmitting.set(false);
// Rediriger vers les détails de la réclamation créée
        this.router.navigate(['/client/complaints', complaint.id]);
      },
      error: (error) => {
        console.error('Erreur création réclamation:', error);
        this.isSubmitting.set(false);
        this.errors.update(errors => ({
          ...errors,
          submit: 'Une erreur est survenue. Veuillez réessayer.'
        }));
      }
    });
  }
  cancel(): void {
    this.router.navigate(['/client/complaints']);
  }
  formatFileSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }
}
