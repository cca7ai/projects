import { Injectable, signal } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import { Observable, of, delay } from 'rxjs';
import { Complaint } from '../../client/complaints/models/complaint.model';
import { User } from '../../../core/models/user.model';
import { UserRole } from '../../../core/models/role.enum';

export interface AdminStats {
  totalUsers: number;
  totalComplaints: number;
  activeComplaints: number;
  resolvedComplaints: number;
  averageResolutionTime: string;
  satisfactionRate: number;
  complaintsByType: { type: string; count: number }[];
  complaintsByStatus: { status: string; count: number }[];
  complaintsTrend: { date: string; count: number }[];
}

export interface UserListItem {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  createdAt: Date;
  lastLogin?: Date;
  isActive: boolean;
  complaintsCount?: number;
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = 'http://localhost:3000/api/admin';

  constructor(private http: HttpClient) {}

  // Récupérer les statistiques globales
  getGlobalStats(): Observable<AdminStats> {
    // TEMPORAIRE : Données mockées
    const mockStats: AdminStats = {
      totalUsers: 156,
      totalComplaints: 342,
      activeComplaints: 48,
      resolvedComplaints: 294,
      averageResolutionTime: '28h',
      satisfactionRate: 87.5,
      complaintsByType: [
        { type: 'defect', count: 142 },
        { type: 'delay', count: 89 },
        { type: 'damaged', count: 67 },
        { type: 'wrong_product', count: 28 },
        { type: 'other', count: 16 }
      ],
      complaintsByStatus: [
        { status: 'open', count: 18 },
        { status: 'in_progress', count: 30 },
        { status: 'resolved', count: 267 },
        { status: 'closed', count: 27 }
      ],
      complaintsTrend: [
        { date: '2024-11-14', count: 12 },
        { date: '2024-11-15', count: 18 },
        { date: '2024-11-16', count: 15 },
        { date: '2024-11-17', count: 22 },
        { date: '2024-11-18', count: 19 },
        { date: '2024-11-19', count: 25 },
        { date: '2024-11-20', count: 20 }
      ]
    };

    return of(mockStats).pipe(delay(500));

    // VERSION AVEC API :
    //return this.http.get<AdminStats>(`${this.apiUrl}/stats`);

  }

  // Liste des utilisateurs
  getUsers(filters?: {
    role?: UserRole;
    search?: string;
    page?: number;
    limit?: number;
  }): Observable<{ users: UserListItem[]; total: number }> {
    // TEMPORAIRE : Données mockées

    const mockUsers: UserListItem[] = [
      {
        id: '1',
        email: 'cca@ecommerce.com',
        firstName: 'Cheick Ahmed',
        lastName: 'COULIBALY',
        role: UserRole.ADMIN,
        createdAt: new Date('2025-11-17'),
        lastLogin: new Date('2025-11-26T09:10:00'),
        isActive: true,
        complaintsCount: 3
      },
      {
        id: '2',
        email: 'mm@ecommerce.com',
        firstName: 'Mehdi',
        lastName: 'MESSADI',
        role: UserRole.CLIENT,
        createdAt: new Date('2025-11-17'),
        lastLogin: new Date('2025-11-26T09:11:00'),
        isActive: true,
        complaintsCount: 0
      },
      {
        id: '3',
        email: 'pierre.durand@example.com',
        firstName: 'Pierre',
        lastName: 'Durand',
        role: UserRole.SAV,
        createdAt: new Date('2025-11-17'),
        lastLogin: new Date('2025-11-26T09:10:00'),
        isActive: true,
        complaintsCount: 0
      },
      {
        id: '4',
        email: 'sophie.bernard@example.com',
        firstName: 'Sophie',
        lastName: 'Bernard',
        role: UserRole.CLIENT,
        createdAt: new Date('2025-11-24'),
        lastLogin: new Date('2025-15-24T09:15:00'),
        isActive: true,
        complaintsCount: 1
      },
      {
        id: '5',
        email: 'admin@example.com',
        firstName: 'Admin',
        lastName: 'System',
        role: UserRole.ADMIN,
        createdAt: new Date('2024-08-01'),
        lastLogin: new Date('2024-11-20T17:00:00'),
        isActive: true,
        complaintsCount: 0
      },
      {
        id: '6',
        email: 'lucas.petit@example.com',
        firstName: 'Lucas',
        lastName: 'Petit',
        role: UserRole.CLIENT,
        createdAt: new Date('2024-10-20'),
        lastLogin: new Date('2024-11-15T10:30:00'),
        isActive: false,
        complaintsCount: 2
      }
    ];

    let filtered = mockUsers;

    if (filters?.role) {
      filtered = filtered.filter(u => u.role === filters.role);
    }

    if (filters?.search) {
      const search = filters.search.toLowerCase();
      filtered = filtered.filter(u =>
        u.firstName.toLowerCase().includes(search) ||
        u.lastName.toLowerCase().includes(search) ||
        u.email.toLowerCase().includes(search)
      );
    }

    return of({
      users: filtered,
      total: filtered.length
    }).pipe(delay(500));

    /* VERSION AVEC API :
    const params = new HttpParams({ fromObject: filters as any });
    return this.http.get<{ users: UserListItem[]; total: number }>(
      `${this.apiUrl}/users`,
      { params }
    );
    */

  }

  // Toutes les réclamations (avec pagination et filtres)
  getAllComplaints(filters?: {
    status?: string;
    priority?: string;
    startDate?: Date;
    endDate?: Date;
    page?: number;
    limit?: number;
  }): Observable<{ complaints: Complaint[]; total: number }> {
    // TEMPORAIRE : Réutiliser les données mockées

    const mockComplaints: Complaint[] = [
      {
        id: '1',
        orderId: 'ORD-2024-001',
        orderNumber: '#12345',
        productId: 'PROD-001',
        productName: 'Smartphone XYZ Pro',
        userId: '1',
        type: 'defect' as any,
        description: 'Pixels morts sur l\'écran',
        priority: 'high' as any,
        status: 'in_progress' as any,
        assignedTo: 'sav-001',
        assignedToName: 'Marie Martin',
        createdAt: new Date('2024-11-17T14:20:00'),
        updatedAt: new Date('2024-11-18T10:30:00')
      },
      {
        id: '2',
        orderId: 'ORD-2024-002',
        orderNumber: '#12346',
        productId: 'PROD-002',
        productName: 'Casque Audio Bluetooth',
        userId: '4',
        type: 'delay' as any,
        description: 'Retard de livraison',
        priority: 'medium' as any,
        status: 'resolved' as any,
        resolution: 'Colis livré avec nos excuses',
        createdAt: new Date('2024-11-16T09:15:00'),
        updatedAt: new Date('2024-11-19T16:45:00'),
        resolvedAt: new Date('2024-11-19T16:45:00')
      },
      {
        id: '3',
        orderId: 'ORD-2024-003',
        orderNumber: '#12347',
        productId: 'PROD-003',
        productName: 'Clavier Mécanique RGB',
        userId: '1',
        type: 'damaged' as any,
        description: 'Colis endommagé',
        priority: 'high' as any,
        status: 'open' as any,
        createdAt: new Date('2024-11-20T08:00:00'),
        updatedAt: new Date('2024-11-20T08:00:00')
      }
    ];

    return of({
      complaints: mockComplaints,
      total: mockComplaints.length
    }).pipe(delay(500));

    // VERSION AVEC API :
    const params = new HttpParams({ fromObject: filters as any });
    return this.http.get<{ complaints: Complaint[]; total: number }>(
      `${this.apiUrl}/complaints`,
      { params }
    );

  }

  // Activer/Désactiver un utilisateur
  toggleUserStatus(userId: string, isActive: boolean): Observable<UserListItem> {
    //return of({} as UserListItem).pipe(delay(500));

    // VERSION AVEC API :
    return this.http.put<UserListItem>(
      `${this.apiUrl}/users/${userId}/status`,
      { isActive }
    );

  }

  // Changer le rôle d'un utilisateur
  changeUserRole(userId: string, role: UserRole): Observable<UserListItem> {
    return of({} as UserListItem).pipe(delay(500));

    /* VERSION AVEC API :
    return this.http.put<UserListItem>(
      `${this.apiUrl}/users/${userId}/role`,
      { role }
    );
    */
  }

  // Supprimer un utilisateur
  deleteUser(userId: string): Observable<void> {
    return of(void 0).pipe(delay(500));

    /* VERSION AVEC API :
    return this.http.delete<void>(`${this.apiUrl}/users/${userId}`);
    */
  }

  // Helper : Formater le nom de rôle
  getRoleLabel(role: UserRole): string {
    const labels: Record<UserRole, string> = {
      [UserRole.CLIENT]: 'Client',
      [UserRole.SAV]: 'Service SAV',
      [UserRole.ADMIN]: 'Administrateur'
    };
    return labels[role];
  }

  // Helper : Variante de badge pour rôle
  getRoleVariant(role: UserRole): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    const variants: Record<UserRole, 'info' | 'warning' | 'danger'> = {
      [UserRole.CLIENT]: 'info',
      [UserRole.SAV]: 'warning',
      [UserRole.ADMIN]: 'danger'
    };
    return variants[role];
  }
}
