import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { Card } from '../../../shared/components';
import { Button } from '../../../shared/components';
import {HomeAssets} from './home-assets';

interface Feature {
  icon: string;
  title: string;
  description: string;
}

interface Category {
  id: string;
  name: string;
  image: string;
  productCount: number;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink, Card, Button],
  templateUrl: './home.html',
  styleUrls: ['./home.scss']
})
export class Home {
  features: Feature[] = [
    {
      icon: '🚚',
      title: 'Livraison rapide',
      description: 'Recevez vos commandes en 24-48h partout en France'
    },
    {
      icon: '🔒',
      title: 'Paiement sécurisé',
      description: 'Tous vos paiements sont protégés et cryptés'
    },
    {
      icon: '💬',
      title: 'SAV réactif',
      description: 'Notre équipe répond à vos réclamations sous 24h'
    },
    {
      icon: '↩️',
      title: 'Retours gratuits',
      description: '30 jours pour changer d\'avis, retours offerts'
    }
  ];

  categories: Category[] = HomeAssets.categories;

  constructor(private router: Router) {}

  navigateToProducts(): void {
    this.router.navigate(['/products']);
  }

  navigateToCategory(categoryId: string): void {
    this.router.navigate(['/products'], { queryParams: { category: categoryId } });
  }

  contactSupport(): void {
    const email = 'sav@ecommerce.cdz';
    const subject = encodeURIComponent('Demande de support');
    const body = encodeURIComponent(
      `Bonjour,\n\nJe vous contacte concernant :\n\n[Décrivez votre demande ici]\n\nCordialement`
    );

    const mailtoLink = `mailto:${email}?subject=${subject}&body=${body}`;

    // Ouvrir le client email par défaut
    window.location.href = mailtoLink;
  }
}
