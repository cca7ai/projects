import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ProductService, Product, Category } from '../services/product.service';
import { ProductCard } from '../product-card/product-card';
import { Card } from '../../../../shared/components';
import { LoadingSpinner } from '../../../../shared/components';
import { Pagination } from '../../../../shared/components';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ProductCard,
    Card,
    LoadingSpinner,
    Pagination
  ],
  templateUrl: './product-list.html',
  styleUrls: ['./product-list.scss']
})
export class ProductList implements OnInit {
  products = signal<Product[]>([]);
  categories = signal<Category[]>([]);
  isLoading = signal(true);

  // Filtres
  selectedCategory = signal<string>('');
  searchQuery = signal('');
  minPrice = signal<number | null>(null);
  maxPrice = signal<number | null>(null);
  sortBy = signal<'price-asc' | 'price-desc' | 'rating' | 'name'>('name');

  // Pagination
  currentPage = signal(1);
  totalPages = signal(1);
  totalItems = signal(0);
  itemsPerPage = 12;

  // Produits filtrés et triés
  displayedProducts = computed(() => {
    let filtered = [...this.products()];

    // Tri
    switch (this.sortBy()) {
      case 'price-asc':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'name':
        filtered.sort((a, b) => a.name.localeCompare(b.name));
        break;
    }

    return filtered;
  });

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Récupérer la catégorie depuis l'URL
    this.route.queryParams.subscribe(params => {
      if (params['category']) {
        this.selectedCategory.set(params['category']);
      }
      this.loadProducts();
    });

    this.loadCategories();
  }

  loadProducts(): void {
    this.isLoading.set(true);

    const filters: any = {
      page: this.currentPage(),
      limit: this.itemsPerPage
    };

    if (this.selectedCategory()) {
      filters.category = this.selectedCategory();
    }

    if (this.searchQuery()) {
      filters.search = this.searchQuery();
    }

    if (this.minPrice()) {
      filters.minPrice = this.minPrice();
    }

    if (this.maxPrice()) {
      filters.maxPrice = this.maxPrice();
    }

    this.productService.getProducts(filters).subscribe({
      next: (response) => {
        this.products.set(response.products);
        this.totalItems.set(response.total);
        this.totalPages.set(Math.ceil(response.total / this.itemsPerPage));
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('Erreur chargement produits:', error);
        this.isLoading.set(false);
      }
    });
  }

  loadCategories(): void {
    this.productService.getCategories().subscribe({
      next: (categories) => {
        this.categories.set(categories);
      }
    });
  }

  selectCategory(categoryId: string): void {
    this.selectedCategory.set(categoryId);
    this.currentPage.set(1);
    this.router.navigate([], {
      queryParams: { category: categoryId || null },
      queryParamsHandling: 'merge'
    });
    this.loadProducts();
  }

  onSearch(): void {
    this.currentPage.set(1);
    this.loadProducts();
  }

  applyPriceFilter(): void {
    this.currentPage.set(1);
    this.loadProducts();
  }

  clearFilters(): void {
    this.selectedCategory.set('');
    this.searchQuery.set('');
    this.minPrice.set(null);
    this.maxPrice.set(null);
    this.currentPage.set(1);
    this.router.navigate([], { queryParams: {} });
    this.loadProducts();
  }

  onProductClick(productId: string): void {
    this.router.navigate(['/products', productId]);
  }

  onAddToCart(product: Product): void {
    console.log('Ajout au panier:', product);
    // TODO: Implémenter la logique du panier
    alert(`${product.name} ajouté au panier !`);
  }

  onPageChange(page: number): void {
    this.currentPage.set(page);
    this.loadProducts();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
