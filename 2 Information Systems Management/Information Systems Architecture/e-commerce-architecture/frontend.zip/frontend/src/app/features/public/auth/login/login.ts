import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../../core/services/auth.service';
import { Card } from '../../../../shared/components';
import { Button } from '../../../../shared/components';
import {UserRole} from '../../../../core/models/role.enum';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule, Card, Button],
  templateUrl: './login.html',
  styleUrls: ['./login.scss']
})
export class Login {
  email = signal('');
  password = signal('');
  isLoading = signal(false);
  errorMessage = signal('');

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  onSubmit(): void {
    this.errorMessage.set('');

    if (!this.email() || !this.password()) {
      this.errorMessage.set('Veuillez remplir tous les champs');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(this.email())) {
      this.errorMessage.set('Email invalide');
      return;
    }

    this.isLoading.set(true);

    // Simuler un délai de connexion
    setTimeout(() => {
      // Déterminer le rôle selon l'email
      let role: UserRole = UserRole.CLIENT;
      if (this.email().includes('sav')) role = UserRole.SAV;
      if (this.email().includes('admin')) role = UserRole.ADMIN;

      // Utiliser la méthode simulateLogin du service
      this.authService.simulateLogin(this.email(), role);

      this.isLoading.set(false);

      // Rediriger selon le rôle
      if (role === UserRole.CLIENT) {
        this.router.navigate(['/client/dashboard']);
      } else if (role === UserRole.SAV) {
        this.router.navigate(['/sav/dashboard']);
      } else if (role === UserRole.ADMIN) {
        this.router.navigate(['/admin/dashboard']);
      }
    }, 1500);
  }
  loginAsClient(): void {
    this.email.set('mm@ecommerce.com');
    this.password.set('PasswordClient123');
    this.onSubmit();
  }
  loginAsSAV(): void {
    this.email.set('nd@ecommerce.com');
    this.password.set('PasswordSav123');
    this.onSubmit();
  }

  loginAsAdmin(): void {
    this.email.set('cca@ecommerce.com');
    this.password.set('PasswordAdmin123');
    this.onSubmit();
  }
}
