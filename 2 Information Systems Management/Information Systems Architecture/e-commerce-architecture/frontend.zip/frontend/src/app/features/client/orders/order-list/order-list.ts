import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { OrderService, Order } from '../services/order.service';
import { Card } from '../../../../shared/components';
import { Badge } from '../../../../shared/components';
import { Button } from '../../../../shared/components';
import { LoadingSpinner } from '../../../../shared/components';

@Component({
  selector: 'app-order-list',
  standalone: true,
  imports: [CommonModule, Card, Badge, Button, LoadingSpinner],
  templateUrl: './order-list.html',
  styleUrls: ['./order-list.scss']
})
export class OrderList implements OnInit {
  orders = signal<Order[]>([]);
  isLoading = signal(true);
  selectedStatus = signal<string>('all');

  filteredOrders = signal<Order[]>([]);

  constructor(
    private orderService: OrderService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadOrders();
  }

  loadOrders(): void {
    this.isLoading.set(true);

    this.orderService.getMyOrders().subscribe({
      next: (orders) => {
        this.orders.set(orders);
        this.filterOrders();
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('Erreur chargement commandes:', error);
        this.isLoading.set(false);
      }
    });
  }

  filterOrders(): void {
    const status = this.selectedStatus();
    if (status === 'all') {
      this.filteredOrders.set(this.orders());
    } else {
      this.filteredOrders.set(
        this.orders().filter(order => order.status === status)
      );
    }
  }

  setStatusFilter(status: string): void {
    this.selectedStatus.set(status);
    this.filterOrders();
  }

  viewOrderDetails(orderId: string): void {
    this.router.navigate(['/client/orders', orderId]);
  }

  createComplaint(orderId: string): void {
    //event.stopPropagation();
    this.router.navigate(['/client/complaints/new'], {
      queryParams: { orderId }
    });
  }

  getStatusLabel(status: string): string {
    return this.orderService.getStatusLabel(status);
  }

  getStatusVariant(status: string): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    return this.orderService.getStatusVariant(status);
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  }

  getTotalItems(order: Order): number {
    return order.items.reduce((sum, item) => sum + item.quantity, 0);
  }
}
