export const HomeAssets = {
  hero: {
    banner: 'assets/images/banners/hero-banner.jpg',
    // Alternative si pas d'image : utiliser du SVG inline
    placeholder: true
  },
  categories: [
    {
      id: 'electronics',
      name: 'Électronique',
      image: 'assets/images/categories/electronics.jpg',
      productCount: 156
    },
    {
      id: 'clothing',
      name: 'Vêtements',
      image: 'assets/images/categories/clothing.jpg',
      productCount: 243
    },
    {
      id: 'home',
      name: 'Maison & Jardin',
      image: 'assets/images/categories/home.jpg',
      productCount: 189
    },
    {
      id: 'sports',
      name: 'Sports & Loisirs',
      image: 'assets/images/categories/sports.jpg',
      productCount: 127
    }
  ]
};
