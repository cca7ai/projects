import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AdminService, AdminStats } from '../../services/admin.service';
import { Card } from '../../../../shared/components';
import { Button } from '../../../../shared/components';
import { LoadingSpinner } from '../../../../shared/components';
import { ComplaintService } from '../../../client/complaints/services/complaint.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    Card,
    Button,
    LoadingSpinner
  ],
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.scss']
})
export class AdminDashboard implements OnInit {
  stats = signal<AdminStats | null>(null);
  isLoading = signal(true);

  constructor(
    private adminService: AdminService,
    private complaintService: ComplaintService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadStats();
  }

  loadStats(): void {
    this.isLoading.set(true);

    this.adminService.getGlobalStats().subscribe({
      next: (stats) => {
        this.stats.set(stats);
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('Erreur chargement stats:', error);
        this.isLoading.set(false);
      }
    });
  }

  navigateTo(route: string): void {
    this.router.navigate([route]);
  }

  getTypeLabel(type: string): string {
    return this.complaintService.getTypeLabel(type as any);
  }

  getStatusLabel(status: string): string {
    return this.complaintService.getStatusLabel(status as any);
  }

  formatDate(date: string): string {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short'
    });
  }
}
