export enum ComplaintStatus {
  OPEN = 'open',
  IN_PROGRESS = 'in_progress',
  RESOLVED = 'resolved',
  CLOSED = 'closed',
  REJECTED = 'rejected'
}

export enum ComplaintType {
  DEFECT = 'defect',
  DELAY = 'delay',
  WRONG_PRODUCT = 'wrong_product',
  DAMAGED = 'damaged',
  OTHER = 'other'
}

export enum ComplaintPriority {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high'
}
