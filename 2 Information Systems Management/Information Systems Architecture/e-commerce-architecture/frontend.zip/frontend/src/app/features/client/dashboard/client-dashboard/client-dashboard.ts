import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { OrderService, Order } from '../../orders/services/order.service';
import { ComplaintService } from '../../complaints/services/complaint.service';
import { Complaint } from '../../complaints/models/complaint.model';
import { AuthService } from '../../../../core/services/auth.service';
import { Card } from '../../../../shared/components';
import { Button } from '../../../../shared/components';
import { Badge } from '../../../../shared/components';
import { LoadingSpinner } from '../../../../shared/components';

interface DashboardStats {
  totalOrders: number;
  activeOrders: number;
  totalComplaints: number;
  pendingComplaints: number;
}

@Component({
  selector: 'app-client-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    Card,
    Button,
    Badge,
    LoadingSpinner
  ],
  templateUrl: './client-dashboard.html',
  styleUrls: ['./client-dashboard.scss']
})
export class ClientDashboard implements OnInit {
  stats = signal<DashboardStats>({
    totalOrders: 0,
    activeOrders: 0,
    totalComplaints: 0,
    pendingComplaints: 0
  });

  recentOrders = signal<Order[]>([]);
  recentComplaints = signal<Complaint[]>([]);
  isLoading = signal(true);

  constructor(
    public authService: AuthService,
    private orderService: OrderService,
    private complaintService: ComplaintService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadDashboardData();
  }

  loadDashboardData(): void {
    this.isLoading.set(true);

    // Charger les commandes
    this.orderService.getMyOrders().subscribe({
      next: (orders) => {
        this.recentOrders.set(orders.slice(0, 3));

        const activeOrders = orders.filter(
          o => o.status === 'processing' || o.status === 'shipped'
        );

        this.stats.update(s => ({
          ...s,
          totalOrders: orders.length,
          activeOrders: activeOrders.length
        }));
      }
    });

    // Charger les réclamations
    this.complaintService.getMyComplaints().subscribe({
      next: (response) => {
        this.recentComplaints.set(response.complaints.slice(0, 3));

        const pendingComplaints = response.complaints.filter(
          c => c.status === 'open' || c.status === 'in_progress'
        );

        this.stats.update(s => ({
          ...s,
          totalComplaints: response.complaints.length,
          pendingComplaints: pendingComplaints.length
        }));

        this.isLoading.set(false);
      }
    });
  }

  navigateToOrders(): void {
    this.router.navigate(['/client/orders']);
  }

  navigateToComplaints(): void {
    this.router.navigate(['/client/complaints']);
  }

  viewOrderDetails(orderId: string): void {
    this.router.navigate(['/client/orders', orderId]);
  }

  viewComplaintDetails(complaintId: string): void {
    this.router.navigate(['/client/complaints', complaintId]);
  }

  getStatusLabel(status: string): string {
    return this.orderService.getStatusLabel(status);
  }

  getStatusVariant(status: string): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    return this.orderService.getStatusVariant(status);
  }

  getComplaintStatusLabel(status: string): string {
    return this.complaintService.getStatusLabel(status as any);
  }

  getComplaintStatusVariant(status: string): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    return this.complaintService.getStatusVariant(status as any);
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short'
    });
  }
}
