import { Component, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../../core/services/auth.service';
import { UserRole } from '../../../../core/models/role.enum';
import { Card } from '../../../../shared/components';
import { Button } from '../../../../shared/components';

interface FormErrors {
  firstName?: string;
  lastName?: string;
  email?: string;
  password?: string;
  confirmPassword?: string;
  terms?: string;
}

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule, Card, Button],
  templateUrl: './register.html',
  styleUrls: ['./register.scss']
})
export class Register {
  // Champs du formulaire
  firstName = signal('');
  lastName = signal('');
  email = signal('');
  password = signal('');
  confirmPassword = signal('');
  termsAccepted = signal(false);

  // État
  isLoading = signal(false);
  errors = signal<FormErrors>({});
  successMessage = signal('');

  // Validation en temps réel
  passwordStrength = computed(() => {
    const pwd = this.password();
    if (pwd.length === 0) return { level: 0, label: '', color: '' };

    let strength = 0;
    if (pwd.length >= 8) strength++;
    if (/[a-z]/.test(pwd)) strength++;
    if (/[A-Z]/.test(pwd)) strength++;
    if (/[0-9]/.test(pwd)) strength++;
    if (/[^a-zA-Z0-9]/.test(pwd)) strength++;

    const levels = [
      { level: 1, label: 'Très faible', color: '#dc3545' },
      { level: 2, label: 'Faible', color: '#fd7e14' },
      { level: 3, label: 'Moyen', color: '#ffc107' },
      { level: 4, label: 'Bon', color: '#28a745' },
      { level: 5, label: 'Excellent', color: '#20c997' }
    ];

    return levels[strength - 1] || levels[0];
  });

  // Computed signals pour chaque critère spécifique
  isLengthValid = computed(() => this.password().length >= 8);
  hasLowerCase = computed(() => /[a-z]/.test(this.password()));
  hasUpperCase = computed(() => /[A-Z]/.test(this.password()));
  hasNumber = computed(() => /[0-9]/.test(this.password()));

  passwordsMatch = computed(() => {
    if (!this.confirmPassword()) return true;
    return this.password() === this.confirmPassword();
  });

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  validateForm(): boolean {
    const newErrors: FormErrors = {};

    // Validation prénom
    if (!this.firstName().trim()) {
      newErrors.firstName = 'Le prénom est requis';
    } else if (this.firstName().length < 2) {
      newErrors.firstName = 'Le prénom doit contenir au moins 2 caractères';
    }

    // Validation nom
    if (!this.lastName().trim()) {
      newErrors.lastName = 'Le nom est requis';
    } else if (this.lastName().length < 2) {
      newErrors.lastName = 'Le nom doit contenir au moins 2 caractères';
    }

    // Validation email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!this.email()) {
      newErrors.email = 'L\'email est requis';
    } else if (!emailRegex.test(this.email())) {
      newErrors.email = 'Email invalide';
    }

    // Validation mot de passe
    if (!this.password()) {
      newErrors.password = 'Le mot de passe est requis';
    } else if (this.password().length < 8) {
      newErrors.password = 'Le mot de passe doit contenir au moins 8 caractères';
    }

    // Validation confirmation mot de passe
    if (!this.confirmPassword()) {
      newErrors.confirmPassword = 'Veuillez confirmer le mot de passe';
    } else if (this.password() !== this.confirmPassword()) {
      newErrors.confirmPassword = 'Les mots de passe ne correspondent pas';
    }

    // Validation conditions
    if (!this.termsAccepted()) {
      newErrors.terms = 'Vous devez accepter les conditions d\'utilisation';
    }

    this.errors.set(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  onSubmit(): void {
    this.successMessage.set('');

    if (!this.validateForm()) {
      return;
    }

    this.isLoading.set(true);

    // TEMPORAIRE : Simuler l'inscription

    setTimeout(() => {
      // Créer le compte (simulation)
      this.authService.simulateLogin(this.email(), UserRole.CLIENT);

      this.isLoading.set(false);
      this.successMessage.set('Compte créé avec succès !');

      // Rediriger vers le dashboard client après 1 seconde
      setTimeout(() => {
        this.router.navigate(['/client/dashboard']);
      }, 1000);
    }, 1500);


    // VERSION AVEC API (à utiliser plus tard) :
    const userData = {
      firstName: this.firstName(),
      lastName: this.lastName(),
      email: this.email(),
      password: this.password()
    };

    this.authService.register(userData).subscribe({
      next: (response) => {
        this.isLoading.set(false);
        if (response.success) {
          this.successMessage.set('Compte créé avec succès !');
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 2000);
        }
      },
      error: (error) => {
        this.isLoading.set(false);
        this.errors.set({
          email: 'Cette adresse email est déjà utilisée'
        });
      }
    });

  }

  // Remplissage rapide pour la démo
  fillDemo(): void {
    this.firstName.set('Cheick');
    this.lastName.set('COULIBALY');
    this.email.set(`client${Date.now()}@example.com`);
    this.password.set('Password123!');
    this.confirmPassword.set('Password123!');
    this.termsAccepted.set(true);
  }
}
