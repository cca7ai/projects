import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ComplaintService } from '../services/complaint.service';
import { Complaint } from '../models/complaint.model';
import { Card } from '../../../../shared/components';
import { Button } from '../../../../shared/components';
import { Badge } from '../../../../shared/components';
import { LoadingSpinner } from '../../../../shared/components';

@Component({
  selector: 'app-complaint-details',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    Card,
    Button,
    Badge,
    LoadingSpinner
  ],
  templateUrl: './complaint-details.html',
  styleUrls: ['./complaint-details.scss']
})
export class ComplaintDetails implements OnInit {
  complaint = signal<Complaint | null>(null);
  isLoading = signal(true);
  newComment = signal('');
  isSendingComment = signal(false);

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private complaintService: ComplaintService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.loadComplaint(id);
    }
  }

  loadComplaint(id: string): void {
    this.isLoading.set(true);

    this.complaintService.getComplaintById(id).subscribe({
      next: (complaint) => {
        if (complaint) {
          this.complaint.set(complaint);
        } else {
          this.router.navigate(['/client/complaints']);
        }
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('Erreur chargement réclamation:', error);
        this.isLoading.set(false);
        this.router.navigate(['/client/complaints']);
      }
    });
  }

  sendComment(): void {
    const text = this.newComment().trim();
    if (!text) return;

    const complaintId = this.complaint()?.id;
    if (!complaintId) return;

    this.isSendingComment.set(true);

    this.complaintService.addComment(complaintId, text).subscribe({
      next: (newComment) => {
        // Recharger la réclamation pour avoir les commentaires à jour

        this.loadComplaint(complaintId);
        this.newComment.set('');
        this.isSendingComment.set(false);
        //this.notificationService.showSuccess('Commentaire ajouté !');
      },
      error: (error) => {
        console.error('Erreur ajout commentaire:', error);
        this.isSendingComment.set(false);
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/client/complaints']);
  }

  getStatusLabel(status: string): string {
    return this.complaintService.getStatusLabel(status as any);
  }

  getStatusVariant(status: string): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    return this.complaintService.getStatusVariant(status as any);
  }

  getTypeLabel(type: string): string {
    return this.complaintService.getTypeLabel(type as any);
  }

  getPriorityLabel(priority: string): string {
    return this.complaintService.getPriorityLabel(priority as any);
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  formatShortDate(date: Date): string {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
}
