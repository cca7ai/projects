import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SavDashboard } from './sav-dashboard';

describe('SavDashboard', () => {
  let component: SavDashboard;
  let fixture: ComponentFixture<SavDashboard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SavDashboard]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SavDashboard);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
