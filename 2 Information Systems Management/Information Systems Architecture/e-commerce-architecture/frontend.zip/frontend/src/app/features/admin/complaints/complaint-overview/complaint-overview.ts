import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import { Complaint } from '../../../client/complaints/models/complaint.model';
import { Card } from '../../../../shared/components';
import { Badge } from '../../../../shared/components';
import { LoadingSpinner } from '../../../../shared/components';
import { Pagination } from '../../../../shared/components';
import { ComplaintService } from '../../../client/complaints/services/complaint.service';

@Component({
  selector: 'app-complaint-overview',
  standalone: true,
  imports: [
    CommonModule,
    Card,
    Badge,
    LoadingSpinner,
    Pagination
  ],
  templateUrl: './complaint-overview.html',
  styleUrls: ['./complaint-overview.scss']
})
export class ComplaintOverview implements OnInit {
  complaints = signal<Complaint[]>([]);
  isLoading = signal(true);
  currentPage = signal(1);
  totalPages = signal(1);
  totalItems = signal(0);
  itemsPerPage = 10;

  selectedStatus = signal<string>('all');
  selectedPriority = signal<string>('all');

  // Stats
  stats = computed(() => {
    const all = this.complaints();
    return {
      total: all.length,
      open: all.filter(c => c.status === 'open').length,
      inProgress: all.filter(c => c.status === 'in_progress').length,
      resolved: all.filter(c => c.status === 'resolved').length,
      high: all.filter(c => c.priority === 'high').length
    };
  });

  constructor(
    private adminService: AdminService,
    private complaintService: ComplaintService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadComplaints();
  }

  loadComplaints(): void {
    this.isLoading.set(true);

    const filters: any = {
      page: this.currentPage(),
      limit: this.itemsPerPage
    };

    if (this.selectedStatus() !== 'all') {
      filters.status = this.selectedStatus();
    }

    if (this.selectedPriority() !== 'all') {
      filters.priority = this.selectedPriority();
    }

    this.adminService.getAllComplaints(filters).subscribe({
      next: (response) => {
        this.complaints.set(response.complaints);
        this.totalItems.set(response.total);
        this.totalPages.set(Math.ceil(response.total / this.itemsPerPage));
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('Erreur chargement réclamations:', error);
        this.isLoading.set(false);
      }
    });
  }

  filterByStatus(status: string): void {
    this.selectedStatus.set(status);
    this.currentPage.set(1);
    this.loadComplaints();
  }

  filterByPriority(priority: string): void {
    this.selectedPriority.set(priority);
    this.currentPage.set(1);
    this.loadComplaints();
  }

  onPageChange(page: number): void {
    this.currentPage.set(page);
    this.loadComplaints();
  }

  viewDetails(id: string): void {
    this.router.navigate(['/admin/complaints', id]);
  }

  getStatusLabel(status: string): string {
    return this.complaintService.getStatusLabel(status as any);
  }

  getStatusVariant(status: string): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    return this.complaintService.getStatusVariant(status as any);
  }

  getTypeLabel(type: string): string {
    return this.complaintService.getTypeLabel(type as any);
  }

  getPriorityLabel(priority: string): string {
    return this.complaintService.getPriorityLabel(priority as any);
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
}
