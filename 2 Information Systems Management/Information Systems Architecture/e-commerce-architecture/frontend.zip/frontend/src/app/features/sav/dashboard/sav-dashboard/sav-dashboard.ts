import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { SavService, SavStats } from '../../services/sav.service';
import { Complaint } from '../../../client/complaints/models/complaint.model';
import { Card } from '../../../../shared/components';
import { Button } from '../../../../shared/components';
import { Badge } from '../../../../shared/components';
import { LoadingSpinner } from '../../../../shared/components';
import { ComplaintService } from '../../../client/complaints/services/complaint.service';

@Component({
  selector: 'app-sav-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    Card,
    Button,
    Badge,
    LoadingSpinner
  ],
  templateUrl: './sav-dashboard.html',
  styleUrls: ['./sav-dashboard.scss']
})
export class SavDashboard implements OnInit {
  stats = signal<SavStats | null>(null);
  urgentComplaints = signal<Complaint[]>([]);
  myComplaints = signal<Complaint[]>([]);
  isLoading = signal(true);

  constructor(
    private savService: SavService,
    private complaintService: ComplaintService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadDashboardData();
  }

  loadDashboardData(): void {
    this.isLoading.set(true);

    // Charger les stats
    this.savService.getStats().subscribe({
      next: (stats) => {
        this.stats.set(stats);
      }
    });

    // Charger les réclamations urgentes
    this.savService.getComplaintQueue({ priority: 'high' }).subscribe({
      next: (complaints) => {
        this.urgentComplaints.set(complaints.slice(0, 3));
      }
    });

    // Charger mes réclamations en cours
    this.savService.getComplaintQueue({
      assignedToMe: true,
      status: 'in_progress' as any
    }).subscribe({
      next: (complaints) => {
        this.myComplaints.set(complaints);
        this.isLoading.set(false);
      }
    });
  }

  viewQueue(): void {
    this.router.navigate(['/sav/complaints']);
  }

  viewComplaint(id: string): void {
    this.router.navigate(['/sav/complaints', id]);
  }

  getStatusLabel(status: string): string {
    return this.complaintService.getStatusLabel(status as any);
  }

  getStatusVariant(status: string): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    return this.complaintService.getStatusVariant(status as any);
  }

  getTypeLabel(type: string): string {
    return this.complaintService.getTypeLabel(type as any);
  }

  getElapsedTime(date: Date): string {
    return this.savService.getElapsedTime(date);
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
}
