// complaint-mock.service.ts
import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ComplaintMockService {
  private complaints: any[] = [];
  private nextId = 1;

  createComplaint(complaintData: any): Observable<any> {
    // Simuler un délai réseau
    const newComplaint = {
      id: this.nextId++,
      ...complaintData,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.complaints.push(newComplaint);

    // Retourner l'observable avec un délai de 500ms pour simuler le réseau
    return of(newComplaint).pipe(delay(500));
  }

  getComplaints(): Observable<any[]> {
    return of(this.complaints).pipe(delay(300));
  }

  getComplaintById(id: number): Observable<any> {
    const complaint = this.complaints.find(c => c.id === id);
    return of(complaint).pipe(delay(300));
  }
}
