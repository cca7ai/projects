import { Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Product } from '../services/product.service';
import { Badge } from '../../../../shared/components';
import { Button } from '../../../../shared/components';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [CommonModule, Badge, Button],
  templateUrl: './product-card.html',
  styleUrls: ['./product-card.scss']
})
export class ProductCard {
  product = input.required<Product>();
  clicked = output<string>();
  addToCart = output<Product>();

  onCardClick(): void {
    this.clicked.emit(this.product().id);
  }

  onAddToCart(): void {
    //event.stopPropagation();
    this.addToCart.emit(this.product());
  }

  getDiscountPercent(): number {
    const product = this.product();
    if (!product.originalPrice) return 0;
    return Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
  }

  getStockStatus(): { label: string; variant: 'success' | 'warning' | 'danger' } {
    const stock = this.product().stock;
    if (stock > 20) return { label: 'En stock', variant: 'success' };
    if (stock > 0) return { label: `Plus que ${stock}`, variant: 'warning' };
    return { label: 'Rupture', variant: 'danger' };
  }
}
