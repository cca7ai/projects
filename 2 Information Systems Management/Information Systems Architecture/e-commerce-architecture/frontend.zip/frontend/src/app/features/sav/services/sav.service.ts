import { Injectable, signal } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import { Observable, of, delay } from 'rxjs';
import { Complaint, ComplaintComment } from '../../client/complaints/models/complaint.model';
import { ComplaintStatus } from '../../client/complaints/models/complaint-status.enum';

export interface SavStats {
  totalAssigned: number;
  pendingQueue: number;
  inProgress: number;
  resolvedToday: number;
  averageResponseTime: string;
}

@Injectable({
  providedIn: 'root'
})
export class SavService {
  private apiUrl = 'http://localhost:3000/api/sav';

  // Signal pour les statistiques
  private statsSignal = signal<SavStats>({
    totalAssigned: 0,
    pendingQueue: 0,
    inProgress: 0,
    resolvedToday: 0,
    averageResponseTime: '0h'
  });
  public stats = this.statsSignal.asReadonly();

  constructor(private http: HttpClient) {
    this.loadMockStats();
  }

  // TEMPORAIRE : Charger des stats mockées
  private loadMockStats(): void {
    this.statsSignal.set({
      totalAssigned: 12,
      pendingQueue: 5,
      inProgress: 4,
      resolvedToday: 3,
      averageResponseTime: '2h 30min'
    });
  }

  // Récupérer la file d'attente des réclamations
  getComplaintQueue(filters?: {
    status?: ComplaintStatus;
    priority?: string;
    assignedToMe?: boolean;
  }): Observable<Complaint[]> {
    // TEMPORAIRE : Données mockées

    const mockComplaints: Complaint[] = [
      {
        id: '3',
        orderId: 'ORD-2024-003',
        orderNumber: '#12347',
        productId: 'PROD-003',
        productName: 'Clavier Mécanique RGB',
        productImage: 'https://via.placeholder.com/100',
        userId: '1',
        type: 'damaged' as any,
        description: 'Le colis est arrivé endommagé, la boîte était ouverte et le clavier a plusieurs touches qui ne fonctionnent pas.',
        priority: 'high' as any,
        status: ComplaintStatus.OPEN,
        createdAt: new Date('2024-11-20T08:00:00'),
        updatedAt: new Date('2024-11-20T08:00:00')
      },
      {
        id: '4',
        orderId: 'ORD-2024-004',
        orderNumber: '#12348',
        productId: 'PROD-004',
        productName: 'Écouteurs Sans Fil',
        productImage: 'https://via.placeholder.com/100',
        userId: '2',
        type: 'defect' as any,
        description: 'Le son grésille et la batterie ne tient que 2 heures au lieu des 8 heures annoncées.',
        priority: 'high' as any,
        status: ComplaintStatus.OPEN,
        createdAt: new Date('2024-11-19T16:30:00'),
        updatedAt: new Date('2024-11-19T16:30:00')
      },
      {
        id: '1',
        orderId: 'ORD-2024-001',
        orderNumber: '#12345',
        productId: 'PROD-001',
        productName: 'Smartphone XYZ Pro',
        productImage: 'https://via.placeholder.com/100',
        userId: '1',
        type: 'defect' as any,
        description: 'L\'écran du smartphone présente des pixels morts dans le coin supérieur droit.',
        priority: 'high' as any,
        status: ComplaintStatus.IN_PROGRESS,
        assignedTo: 'sav-001',
        assignedToName: 'Marie Martin',
        comments: [
          {
            id: 'c1',
            userId: 'sav-001',
            userName: 'Marie Martin',
            userRole: 'SAV',
            text: 'Bonjour, nous avons bien pris en compte votre réclamation. Pouvez-vous nous envoyer une photo du défaut ?',
            createdAt: new Date('2024-11-18T10:30:00')
          }
        ],
        createdAt: new Date('2024-11-17T14:20:00'),
        updatedAt: new Date('2024-11-18T10:30:00')
      },
      {
        id: '5',
        orderId: 'ORD-2024-005',
        orderNumber: '#12349',
        productId: 'PROD-005',
        productName: 'Montre Connectée',
        productImage: 'https://via.placeholder.com/100',
        userId: '3',
        type: 'other' as any,
        description: 'La synchronisation avec mon téléphone ne fonctionne pas, j\'ai essayé de réinstaller l\'application plusieurs fois.',
        priority: 'medium' as any,
        status: ComplaintStatus.OPEN,
        createdAt: new Date('2024-11-19T11:00:00'),
        updatedAt: new Date('2024-11-19T11:00:00')
      },
      {
        id: '6',
        orderId: 'ORD-2024-006',
        orderNumber: '#12350',
        productId: 'PROD-006',
        productName: 'Tablette Graphique',
        productImage: 'https://via.placeholder.com/100',
        userId: '4',
        type: 'defect' as any,
        description: 'Le stylet ne répond plus après 2 jours d\'utilisation. J\'ai changé les piles mais ça ne fonctionne toujours pas.',
        priority: 'medium' as any,
        status: ComplaintStatus.IN_PROGRESS,
        assignedTo: 'sav-002',
        assignedToName: 'Pierre Durand',
        createdAt: new Date('2024-11-18T09:15:00'),
        updatedAt: new Date('2024-11-19T14:20:00')
      }
    ];

    let filtered = mockComplaints;

    if (filters?.status) {
      filtered = filtered.filter(c => c.status === filters.status);
    }

    if (filters?.priority) {
      filtered = filtered.filter(c => c.priority === filters.priority);
    }

    if (filters?.assignedToMe) {
      filtered = filtered.filter(c => c.assignedTo === 'sav-001');
    }

    // Trier : non assignées d'abord, puis par priorité et date
    filtered.sort((a, b) => {
      if (!a.assignedTo && b.assignedTo) return -1;
      if (a.assignedTo && !b.assignedTo) return 1;

      const priorityOrder: any = { high: 0, medium: 1, low: 2 };
      const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority];
      if (priorityDiff !== 0) return priorityDiff;

      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    });

    return of(filtered).pipe(delay(500));

    /* VERSION AVEC API :
    const params = new HttpParams({ fromObject: filters as any });
    return this.http.get<Complaint[]>(`${this.apiUrl}/complaints/queue`, { params });
    */
  }

  // Assigner une réclamation à soi-même
  assignToMe(complaintId: string): Observable<Complaint> {
    // TEMPORAIRE : Simuler l'assignation
    //return of({} as Complaint).pipe(delay(500));
    return this.http.put<Complaint>(`${this.apiUrl}/complaints/${complaintId}/assign`, {});

    /* VERSION AVEC API :
    return this.http.put<Complaint>(`${this.apiUrl}/complaints/${complaintId}/assign`, {});
    */
  }

  // Mettre à jour le statut
  updateStatus(complaintId: string, status: ComplaintStatus, resolution?: string): Observable<Complaint> {
    // TEMPORAIRE : Simuler la mise à jour
    return of({} as Complaint).pipe(delay(500));

    // VERSION AVEC API :
    /*return this.http.put<Complaint>(
      `${this.apiUrl}/complaints/${complaintId}/status`,
      { status, resolution }
    );
    */

  }

  // Ajouter une réponse SAV
  addSavResponse(complaintId: string, text: string): Observable<ComplaintComment> {
    const newComment: ComplaintComment = {
      id: Date.now().toString(),
      userId: 'sav-001',
      userName: 'Marie Martin',
      userRole: 'SAV',
      text: text,
      createdAt: new Date()
    };

    return of(newComment).pipe(delay(500));

    /*VERSION AVEC API :
    return this.http.post<ComplaintComment>(
      `${this.apiUrl}/complaints/${complaintId}/response`,
      { text }
    );
    */

  }

  // Récupérer les statistiques
  getStats(): Observable<SavStats> {
    return of(this.statsSignal()).pipe(delay(300));

    /* VERSION AVEC API :
    return this.http.get<SavStats>(`${this.apiUrl}/stats`);
    */
  }

  // Helper : Temps écoulé depuis la création
  getElapsedTime(createdAt: Date): string {
    const now = new Date();
    const diff = now.getTime() - new Date(createdAt).getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);

    if (hours < 1) return 'Il y a moins d\'1h';
    if (hours < 24) return `Il y a ${hours}h`;
    if (days === 1) return 'Il y a 1 jour';
    return `Il y a ${days} jours`;
  }

  // Helper : Urgence basée sur la priorité et le temps
  getUrgencyLevel(complaint: Complaint): 'critical' | 'high' | 'normal' {
    const hoursSinceCreation = (new Date().getTime() - new Date(complaint.createdAt).getTime()) / (1000 * 60 * 60);

    if (complaint.priority === 'high' && hoursSinceCreation > 24) return 'critical';
    if (complaint.priority === 'high') return 'high';
    if (complaint.priority === 'medium' && hoursSinceCreation > 48) return 'high';

    return 'normal';
  }
}
