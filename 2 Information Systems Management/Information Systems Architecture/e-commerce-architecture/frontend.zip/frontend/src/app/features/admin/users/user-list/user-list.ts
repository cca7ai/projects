import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService, UserListItem } from '../../services/admin.service';
import { UserRole } from '../../../../core/models/role.enum';
import { Card } from '../../../../shared/components';
import { Badge } from '../../../../shared/components';
import { LoadingSpinner } from '../../../../shared/components';
import { Modal } from '../../../../shared/components';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    Card,
    Badge,
    LoadingSpinner,
    Modal
  ],
  templateUrl: './user-list.html',
  styleUrls: ['./user-list.scss']
})
export class UserList implements OnInit {
  users = signal<UserListItem[]>([]);
  isLoading = signal(true);
  searchQuery = signal('');
  selectedRole = signal<UserRole | 'all'>('all');

  // Modal de confirmation
  showDeleteModal = signal(false);
  userToDelete = signal<UserListItem | null>(null);

  // Stats
  totalUsers = signal(0);

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.isLoading.set(true);

    const filters: any = {};
    if (this.selectedRole() !== 'all') {
      filters.role = this.selectedRole();
    }
    if (this.searchQuery()) {
      filters.search = this.searchQuery();
    }

    this.adminService.getUsers(filters).subscribe({
      next: (response) => {
        this.users.set(response.users);
        this.totalUsers.set(response.total);
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('Erreur chargement utilisateurs:', error);
        this.isLoading.set(false);
      }
    });
  }

  filterByRole(role: UserRole | 'all'): void {
    this.selectedRole.set(role);
    this.loadUsers();
  }

  onSearch(): void {
    this.loadUsers();
  }

  toggleUserStatus(user: UserListItem): void {
    const newStatus = !user.isActive;

    this.adminService.toggleUserStatus(user.id, newStatus).subscribe({
      next: () => {
        user.isActive = newStatus;
        this.loadUsers();
      },
      error: (error) => {
        console.error('Erreur changement statut:', error);
      }
    });
  }

  changeRole(user: UserListItem, newRole: UserRole): void {
    this.adminService.changeUserRole(user.id, newRole).subscribe({
      next: () => {
        this.loadUsers();
      },
      error: (error) => {
        console.error('Erreur changement rôle:', error);
      }
    });
  }

  confirmDelete(user: UserListItem): void {
    this.userToDelete.set(user);
    this.showDeleteModal.set(true);
  }

  deleteUser(): void {
    const user = this.userToDelete();
    if (!user) return;

    this.adminService.deleteUser(user.id).subscribe({
      next: () => {
        this.showDeleteModal.set(false);
        this.userToDelete.set(null);
        this.loadUsers();
      },
      error: (error) => {
        console.error('Erreur suppression utilisateur:', error);
      }
    });
  }

  getRoleLabel(role: UserRole): string {
    return this.adminService.getRoleLabel(role);
  }

  getRoleVariant(role: UserRole): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    return this.adminService.getRoleVariant(role);
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  }

  getTimeAgo(date?: Date): string {
    if (!date) return 'Jamais';

    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 60) return `Il y a ${minutes}min`;
    if (hours < 24) return `Il y a ${hours}h`;
    if (days === 1) return 'Hier';
    if (days < 7) return `Il y a ${days} jours`;
    return this.formatDate(date);
  }

  protected readonly UserRole = UserRole;
}
