import { ComplaintStatus, ComplaintType, ComplaintPriority } from './complaint-status.enum';

export interface Complaint {
  id: string;
  orderId: string;
  orderNumber: string;
  productId: string;
  productName: string;
  productImage?: string;
  userId: string;
  type: ComplaintType;
  description: string;
  priority: ComplaintPriority;
  status: ComplaintStatus;
  attachments?: string[];
  assignedTo?: string;
  assignedToName?: string;
  resolution?: string;
  comments?: ComplaintComment[];
  createdAt: Date;
  updatedAt: Date;
  resolvedAt?: Date;
}

export interface ComplaintComment {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  text: string;
  createdAt: Date;
}

export interface CreateComplaintDto {
  orderId: string;
  productId: string;
  type: ComplaintType;
  description: string;
  priority?: ComplaintPriority;
  attachments?: File[];
}
