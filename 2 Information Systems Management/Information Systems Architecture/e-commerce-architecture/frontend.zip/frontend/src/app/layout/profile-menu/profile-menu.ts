import { Component, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { UserRole } from '../../core/models/role.enum';

interface MenuItem {
  icon: string;
  label: string;
  link: string;
  roles?: UserRole[];
}

@Component({
  selector: 'app-profile-menu',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './profile-menu.html',
  styleUrls: ['./profile-menu.scss']
})
export class ProfileMenu {
  menuItems = computed<MenuItem[]>(() => {
    const user = this.authService.currentUser();
    if (!user) return [];

    const baseItems: MenuItem[] = [
      {
        icon: `<svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
          <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/>
        </svg>`,
        label: 'Accueil',
        link: this.getDashboardLink(user.role)
      },
      {
        icon: `<svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
          <path d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"/>
        </svg>`,
        label: 'Profil',
        link: this.getProfileLink(user.role)
      },
      {
        icon: `<svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
          <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/>
          <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd"/>
        </svg>`,
        label: 'Historique',
        link: this.getHistoryLink(user.role)
      },
      {
        icon: `<svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
          <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
        </svg>`,
        label: 'Paramètres',
        link: this.getSettingsLink(user.role)
      }
    ];

    return baseItems;
  });

  constructor(
    public authService: AuthService,
    private router: Router
  ) {}

  private getDashboardLink(role: UserRole): string {
    const dashboards: Record<UserRole, string> = {
      [UserRole.CLIENT]: '/client/dashboard',
      [UserRole.SAV]: '/sav/dashboard',
      [UserRole.ADMIN]: '/admin/dashboard'
    };
    return dashboards[role];
  }

  private getProfileLink(role: UserRole): string {
    const profiles: Record<UserRole, string> = {
      [UserRole.CLIENT]: '/client/profile',
      [UserRole.SAV]: '/sav/profile',
      [UserRole.ADMIN]: '/admin/profile'
    };
    return profiles[role];
  }

  private getHistoryLink(role: UserRole): string {
    const history: Record<UserRole, string> = {
      [UserRole.CLIENT]: '/client/orders',
      [UserRole.SAV]: '/sav/complaints',
      [UserRole.ADMIN]: '/admin/complaints'
    };
    return history[role];
  }

  private getSettingsLink(role: UserRole): string {
    const settings: Record<UserRole, string> = {
      [UserRole.CLIENT]: '/client/settings',
      [UserRole.SAV]: '/sav/settings',
      [UserRole.ADMIN]: '/admin/settings'
    };
    return settings[role];
  }
}
