import {Component, inject, input, output} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Router, RouterLink, RouterLinkActive} from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { Button } from '../../shared/components';
import { Badge } from '../../shared/components';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, Button, Badge, FormsModule],
  templateUrl: './header.html',
  styleUrls: ['./header.scss']
})
export class Header {
  // Inputs
  showSearch = input<boolean>(true);

  // Outputs
  searchQuery = output<string>();
  menuToggled = output<void>();

  isUserMenuOpen = false;
  searchValue = '';

  private router = inject(Router);
  navigateToLogin(): void {
    this.router.navigate(['/login']);
  }
  constructor(public authService: AuthService) {}

  onSearch(): void {
    if (this.searchValue.trim()) {
      this.searchQuery.emit(this.searchValue);
    }
  }

  toggleUserMenu(): void {
    this.isUserMenuOpen = !this.isUserMenuOpen;
  }

  logout(): void {
    this.authService.logout();
    this.isUserMenuOpen = false;
  }

  toggleMobileMenu(): void {
    this.menuToggled.emit();
  }
}
