import { Component, input, output, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { UserRole } from '../../core/models/role.enum';
import { Badge } from '../../shared/components';

interface MenuItem {
  label: string;
  icon: string;
  link: string;
  roles: UserRole[];
  badge?: number;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, Badge],
  templateUrl: './sidebar.html',
  styleUrls: ['./sidebar.scss']
})
export class Sidebar {
  isOpen = input<boolean>(true);
  closed = output<void>();

  constructor(public authService: AuthService) {}

  menuItems = computed<MenuItem[]>(() => {
    const user = this.authService.currentUser();
    if (!user) return [];

    if (user.role === UserRole.CLIENT) {
      return [
        { label: 'Tableau de bord', icon: 'dashboard', link: '/client/dashboard', roles: [UserRole.CLIENT] },
        { label: 'Mes commandes', icon: 'orders', link: '/client/orders', roles: [UserRole.CLIENT] },
        { label: 'Mes réclamations', icon: 'complaints', link: '/client/complaints', roles: [UserRole.CLIENT], badge: 2 },
        { label: 'Mon profil', icon: 'profile', link: '/client/profile', roles: [UserRole.CLIENT] }
      ];
    }

    if (user.role === UserRole.SAV) {
      return [
        { label: 'Tableau de bord', icon: 'dashboard', link: '/sav/dashboard', roles: [UserRole.SAV] },
        { label: 'File d\'attente', icon: 'queue', link: '/sav/complaints', roles: [UserRole.SAV], badge: 5 },
        { label: 'En cours', icon: 'progress', link: '/sav/complaints/in-progress', roles: [UserRole.SAV] },
        { label: 'Statistiques', icon: 'stats', link: '/sav/statistics', roles: [UserRole.SAV] }
      ];
    }

    if (user.role === UserRole.ADMIN) {
      return [
        { label: 'Tableau de bord', icon: 'dashboard', link: '/admin/dashboard', roles: [UserRole.ADMIN] },
        { label: 'Utilisateurs', icon: 'users', link: '/admin/users', roles: [UserRole.ADMIN] },
        { label: 'Réclamations', icon: 'complaints', link: '/admin/complaints', roles: [UserRole.ADMIN], badge: 12 },
        { label: 'Produits', icon: 'products', link: '/admin/products', roles: [UserRole.ADMIN] },
        { label: 'Statistiques', icon: 'stats', link: '/admin/statistics', roles: [UserRole.ADMIN] }
      ];
    }

    return [];
  });

  closeSidebar(): void {
    this.closed.emit();
  }

  getRoleLabel(role: UserRole): string {
    const labels: Record<UserRole, string> = {
      [UserRole.CLIENT]: 'Client',
      [UserRole.SAV]: 'Service SAV',
      [UserRole.ADMIN]: 'Administrateur'
    };
    return labels[role];
  }

  getRoleVariant(role: UserRole): 'success' | 'warning' | 'danger' | 'info' | 'default' {
    const variants: Record<UserRole, 'info' | 'warning' | 'danger'> = {
      [UserRole.CLIENT]: 'info',
      [UserRole.SAV]: 'warning',
      [UserRole.ADMIN]: 'danger'
    };
    return variants[role];
  }
}
