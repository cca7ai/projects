import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from './core/services/auth.service';

import {RouterOutlet} from '@angular/router';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  title = 'ecommerce';

  //Test du module CORE
  constructor(public authService: AuthService) {
    console.log('User connecté:', this.authService.currentUserValue);
  }

  //Test du module SHARED
  isLoading = signal(false);
  isModalOpen = signal(false);

  currentPage = signal(1);
  totalPages = signal(10);
  totalItems = signal(95);
  itemsPerPage = signal(10);

  onButtonClick(): void {
    console.log('Button clicked!');
    this.isLoading.set(true);
    setTimeout(() => this.isLoading.set(false), 2000);
  }

  openModal(): void {
    this.isModalOpen.set(true);
  }

  closeModal(): void {
    this.isModalOpen.set(false);
  }

  onConfirm(): void {
    console.log('Confirmé!');
    this.closeModal();
  }

  onPageChange(page: number): void {
    console.log('Changement de page:', page);
    this.currentPage.set(page);
  }
}
