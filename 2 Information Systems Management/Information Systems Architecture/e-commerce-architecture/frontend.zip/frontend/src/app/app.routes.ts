import { Routes } from '@angular/router';
import { MainLayout } from './layout/main-layout/main-layout';
import { DashboardLayout } from './layout/dashboard-layout/dashboard-layout';
import { Home } from './features/public/home/home';
import { Login } from './features/public/auth/login/login';
import { Register } from './features/public/auth/register/register';
import { ProductList } from './features/public/products/product-list/product-list';
import { ClientDashboard } from './features/client/dashboard/client-dashboard/client-dashboard';
import { OrderList } from './features/client/orders/order-list/order-list';
import { ComplaintList } from './features/client/complaints/complaint-list/complaint-list';
import { ComplaintDetails } from './features/client/complaints/complaint-details/complaint-details';
import { ComplaintForm } from './features/client/complaints/complaint-form/complaint-form';
import { SavDashboard } from './features/sav/dashboard/sav-dashboard/sav-dashboard';
import { ComplaintQueue } from './features/sav/complaints/complaint-queue/complaint-queue';
import { AdminDashboard } from './features/admin/dashboard/admin-dashboard/admin-dashboard';
import { UserList } from './features/admin/users/user-list/user-list';
import { ComplaintOverview } from './features/admin/complaints/complaint-overview/complaint-overview';
export const routes: Routes = [
// Routes publiques avec MainLayout
  {
    path: '',
    component: MainLayout,
    children: [
      { path: '', component: Home },
      { path: 'products', component: ProductList },
      { path: 'login', component: Login },
      { path: 'register', component: Register }
    ]
  },
// Routes client avec DashboardLayout
  {
    path: 'client',
    component: DashboardLayout,
    children: [
      { path: 'dashboard', component: ClientDashboard },
      { path: 'orders', component: OrderList },
      {
        path: 'complaints',
        children: [
          { path: '', component: ComplaintList },
          { path: 'new', component: ComplaintForm },
          { path: ':id', component: ComplaintDetails }
        ]
      }
    ]
  },
// Routes SAV avec DashboardLayout
  {
    path: 'sav',
    component: DashboardLayout,
    children: [
      { path: 'dashboard', component: SavDashboard },
      {
        path: 'complaints',
        children: [
          { path: '', component: ComplaintQueue },
          { path: ':id', component: ComplaintDetails }
        ]
      }
    ]
  },
// Routes admin avec DashboardLayout
  {
    path: 'admin',
    component: DashboardLayout,
    children: [
      { path: 'dashboard', component: AdminDashboard },
      { path: 'users', component: UserList },
      {
        path: 'complaints',
        children: [
          { path: '', component: ComplaintOverview },
          { path: ':id', component: ComplaintDetails }
        ]
      }
    ]
  },
// Redirection
  { path: '**', redirectTo: '' }
];
